#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

#define TRUE 1
#define FALSE !TRUE //0

void loc(void);
void main(void);
void hallway(void);
void trapmain(void);
void getplstat(void);
void searchmain(void);
void searchmain2(void);
void main2(void);
void exadoor(void);
void traploc(void);
void searchloc(void);
void quit_a(void);
void flee_1(void);
void att_1(void);
void hallway2(void);
void pldeath(void);
void hallway3(void);
void main3(void);
void westroom(void);
void smsbed(void);
void westroom1(void);
void wstrmshelfes(void);
void westroom2(void);
void hallway5(void);
void exroom(void);
void wstrmtraps(void);
void searchwstrm(void);
void hallway4(void);
void midroom(void);
void eastroom(void);
void ption(void);
void eastroom1(void);
void estitm(void);
void traphallway(void);
void search_hallway(void);
void westdr(void);
void storage(void);
void att_2(void);
void storage1(void);
void flee_3(void);
void storagetraps(void);
void storageitems(void);
void strsthdr(void);
void search_kitchen(void);
void traps_kitchen(void);
void bossroom(void);
void jujuatt(void);
void bossdead(void);
void nextlev_b(void);
void bosstraps(void);
void bossitm(void);
void wstdrent(void);
void rmtraps(void);
void glmitm(void);
void adv1_a(void);
void estgolems(void);
void free_to_exit(void);
void exiit(void);
void town(void);
void stayer(void);

extern struct player{
	   char name[16];
		int gp;
		int life;
		int medlife;
		int xp;
		int findchance;
		int nextlev;
		int thaco;
		int armor;
   	int dmg;
	   char weapons_carry[16];
   	char protection[16];
		}loaded;


int shp_1=6;   //used in the hallway battle
int shp_2=4;   //used in the hallway battle
int st=1;      //used in the hallway battle

int zhp_1=4;   //Used in westroom battle
int zhp_2=10;  //Used in westroom battle
int st2=2;     //Used in westroom battle
int st2a=2;    //Used in westroom battle

int jhp=27;    //The horrible ju-ju zombies hp

int ghp1=17;	  //Golem #1's hp
int ghp2=14;     //Golem #2's hp

int gkey=1;    //Required to enter westdoor
int key=0;     //Required to open door
int tilbake=0; //Required to return to the right function
int cont=1;    //Controls finding in shelfes in westroom
int all_i=1;   //Controlls finding in Eastroom
int trap=1;    //Controlls trap in hallway

int smash_1=1; //Is the bed smashed or not?
int zdeath=0;  //Are the zombies dead or not?
int gdeath=0;  //And the golems?
int xputd=0;   //Is the player going to recieve xp?
int gpfind=0;  //Is the player going to find anything?
int gpfind2=0; //Is the player going to find anything?
int kitchenfinder=0;  //Is the player going to find anything in the kitchen?
int kchtrap=1; //Is the trap disarmed?
int juju=0;    //Did the ju-ju zombie kill you?
int juxp=0;    //Are you going to receive xp
int glm=1;		//Has the player allready found the 1 GP?
int xpcheck=0;

char chooce[1];
int choice;
int find;


void adv1_a()
{
   if(juju>0) juju=0;

	printf("\n\nYou wake up in a dark room only lit by 2 torches.\n");
   printf("You feel a slight headake as you remember that someone hit you\n");
   printf("in the back of you'r head.\n");
   printf("You can't seem to remember to ever have been here before.\n");
   printf("The walls are made of large stone blocks.\n");
   printf("The floor is made of dirt.\n");
	printf("The room is 6 meters to the north, and 4 meters to the east.\n");
   printf("There is one door at the middle of the north wall and one at\n");
   printf("the middle of the east wall.\n\n");
   printf("You can:\n\n");
	printf("Go through the east wall door(1)\n");
   printf("Go through the north wall door(2)\n");
   printf("Search for traps in this room(3)\n");
   printf("Search the room for any items(4)\n");
   printf("Get player Stats(5)\n");
   printf("Quit(6)\n\n");
	choice=atoi(gets(chooce));
   if(choice==1)loc();
   if(choice==2)hallway();
   if(choice==3)trapmain();
   if(choice==4)searchmain();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<0)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }

   main2();
}

void loc(void)
{
	printf("\n\nYou are in a small room that seems to serve no\n");
   printf("purpose. It just is there between the door you just came\n");
	printf("through and another door at the end of the room(east wall).\n");
   printf("The door at the east wall in this room is made of solid steal.\n");
   printf("The room is 2 meters to the north and 2 meters to the east.\n");
   printf("There is one torch at the north wall lighting the room.\n");
   printf("The room is smells bad and the walls are partly covered with mud.\n");
   printf("The walls are made of large stone blocks.\n\n");
   printf("You can:\n");
   printf("Go through the west wall door(1)\n");
   printf("Go through the east wall door(2)\n");
   printf("Search the room for traps(3)\n");
   printf("Search the room for items(4)\n");
   printf("Get player stats(5)\n\n");
   choice=atoi(gets(chooce));
	if(choice==1)main2();
   if(choice==2)exadoor();
   if(choice==3)traploc();
   if(choice==4)searchloc();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<0)
   {
   	printf("\nChoices must range from 1 to 6.\n");
   	getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 6.\n");
   	getch();
   }

   loc();
}

void hallway(void)
{

	printf("\n\nYou are in a long hallway that is about 2 meters to the north,\n");
	printf("5 meters to the west and 3 meters to the east.\n");
   printf("There are 3 doors at the north wall and one at the west wall.\n");
   printf("There is allso one door besides the one you just came through to the west.\n");
   printf("It is ca. 1 meter to the west for the door you just came through.\n");
	printf("The hallway is dirty, the floor is made of dirt and the walls\n");
   printf("are made of large stones.\n");
   printf("The walls are partly covered with dirt, and all the doors are made\n");
   printf("of wood. At the west end of the hallway, there are 2 skeletons.\n");
   printf("Both of them raise theyr Short Swords and run towards you.\n");
   printf("They seem a little slow as they run.\n\n");
   printf("You can:\n\n");
   printf("Attack(1)\n");
   printf("Flee(2)\n");
   printf("Get player stats(3)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)att_1();
   if(choice==2)flee_1();
   if(choice==3)getplstat();
   if(choice==4)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }

   hallway();
}
void trapmain(void)
{

	printf("You find no traps.\n");
   getch();
	main2();

}
void searchmain(void)
{

	printf("Hit a key to see if you find anything:");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%10+1+loaded.findchance;
   if(find>6)
   {
   	printf("\nYou found 2 Gold coins.\n");
      loaded.gp+=2;
      getch();
      main2();
   }
   if(find<=6)
   {
   	printf("\nYou didn't find anything.\n");
      getch();
   	main2();
	}
}
void getplstat(void)
{
   if(key==1 && gkey==2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("You allso have a normal key, and a strange looking key.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
	}
   if(key>1 && gkey==2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("They key you had is stuck in the door it fits into.\n");
      printf("You still have the strange looking key.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
	}
   if(key>1 && gkey>2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("They key you had is stuck in the door it fits into.\n");
      printf("Allso the strange looking key is stuck in the it's keyhole.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
	}
	if(key==1 && gkey<2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("You allso have a key.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
	}
   if(key>1 && gkey<2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("They key you had is stuck in the door it fits into.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
	}
   if(key<1 && gkey<2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
   }
   if(key<1 && gkey==2)
   {
   	printf("\n\nYou have %i Gold Coins, %i Hit Points, and %i Experience.\n",loaded.gp,loaded.life,loaded.xp);
   	printf("You are carrying a Long-Sword, wearing a Chain-Mail armor, and you'r\n");
   	printf("find chance is %i\n", loaded.findchance);
      printf("You allso have a strange looking key.\n");
   	printf("You need %i in Experience to get to next level.\n",loaded.nextlev);
   	getch();
   }
}
void main2(void)
{
	printf("\n\nYou are in a dark room that is only lit by 2 torches.\n");
   printf("The walls are made of large stone blocks.\n");
   printf("The floor is made of dirt.\n");
	printf("The room is 6 meters to the north, and 4 meters to the east.\n");
   printf("There is one door at the middle of the north wall and one at\n");
   printf("the middle of the east wall.\n\n");
   printf("You can:\n\n");
	printf("Go through the east wall door(1)\n");
   printf("Go through the north wall door(2)\n");
   printf("Search for traps in this room(3)\n");
   printf("Search the room for any items(4)\n");
   printf("Get player Stats(5)\n");
   printf("Quit(6)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)loc();
   if(choice==2)hallway();
   if(choice==3)trapmain();
   if(choice==4)searchmain2();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<0)
   {

	   printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }

   main2();
}
void searchmain2(void)
{
	printf("\nYou search the room and you don't find anything.\n");
   getch();
   main2();
}
void exadoor(void)
{
   if(key==1)
   {
   	printf("\n\nSince the door at the east end is locked, you try to use the\n");
      printf("key you found to open it. It workes!\n");
      getch();
      printf("Whoopsie! They key is stuck in the keyhole...  You can't get it out.\n");
      key++;
      getch();
   }
   if(key==2)
   {
   	printf("\n\nYou are in a room that is 3 meters to the north, 3 meters to the south\n");
   	printf("(from the west wall door) and 5 meters to the east.\n");
      getch();
      exroom();
   }
   else
   {
		printf("\nThe door is locked.\n");
   	getch();
   	loc();
   }

}
void traploc(void)
{
	printf("\nYou find no traps here.\n");
   getch();
   loc();
}
void searchloc(void)
{
	printf("Hit a key to see if you find anything:");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%10+1+loaded.findchance;
   if(find>=10)
   {
   	printf("\nYou found a note between two of the large stone blocks that says:.\n");
      printf("In the bedroom to the right.\n");
      getch();
      loc();
   }
   if(find<10)
   {
   	printf("\nYou didn't find anything.\n");
      getch();
   	loc();
	}
}
void quit_a(void)
{
	exit(1);
}
void flee_1(void)
{

	printf("\nYou try to run away, but before you even manage\n");
   printf("to turn around you feel the blade of the skeletons shortsword\n");
   printf("going through you'r brain. You'r dead allmighty hero!");
   getch();
   exit(1);
}
void att_1(void)
{
   unsigned int plhit,monhit,clhit,tpmon,dam,xc; //tpmon is used for wich of them you hit
   int th=19;
   int ac=7;
   int ranatt;
   int ranatt2;
   int ranatt3;
   int first=1;
   unsigned int end=0;

   for(xc=0;xc<2;)
   {
      if(first==1)
      {
			printf("\n\nYou raise you'r sword and attack.\n");
   		printf("Hit a button to see if you hit.\n");
      	first++;
   		getch();
      }
      else
      {
      	srand((unsigned)time(NULL));
      	ranatt2=rand()%8+1;
			if(ranatt2==1)printf("\nYou swing you'r sword in a attempt to cut the skeletons head off.\n");
      	if(ranatt2==2)printf("\nYou try to cut the skeleton in half from above.\n");
      	if(ranatt2==3)printf("\nYou swing you'r sword in a hope to fatally damage the skeleton.\n");
      	if(ranatt2==4)printf("\nYou try to cut the skeleton in half through his guts(or what once was his guts).\n");
      	if(ranatt2==5)printf("\nYou try to cut off his right arm.\n");
      	if(ranatt2==6)printf("\nYou try to cut off his leg.\n");
      	if(ranatt2==7)printf("\nYou go berserk and raise your sword in a wild attack.\n");
      	if(ranatt2==8)printf("\nYou just swing your sword at the skeletons in a hope of hitting.\n");
         printf("Hit a button to see if you hit.\n");
         getch();
      }
   	srand((unsigned)time(NULL));
   	clhit=rand()%20+1;
   	plhit=loaded.thaco-clhit;
   	if(plhit<=ac)
   	{
      	srand((unsigned)time(NULL));
      	tpmon=rand()%10+1;
      	if(tpmon<=5)
      	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		shp_1-=dam;
         	printf("\nYou hit the smallest one of them for %i Hit Points.\n",dam);
         	getch();
			}
			if(tpmon>=6)
      	{
         	if(st<3)
         	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		shp_2-=dam;
         	printf("\nYou hit the largest one of them for %i Hit Points.\n",dam);
         	getch();
				}
            else printf("\nYou totally missed dude!\n");
			}
		}
   	else
      {
         srand((unsigned)time(NULL));
         ranatt=rand()%8+1;
			if(ranatt==1)printf("\nYou didn't hit.\n");
         if(ranatt==2)printf("\nThe skeleton blocks your attack with his short sword.\n");
         if(ranatt==3)printf("\nThe skeleton dodges your attack.\n");
         if(ranatt==4)printf("\nYou miss the skeleton with a inch.\n");
         if(ranatt==5)printf("\nThe skeleton leaps to the leaft, away from your attack.\n");
         if(ranatt==6)printf("\nYou miss and your sword allmost falls out of your hands.\n");
         if(ranatt==7)printf("\nYou simply miss.\n");
         if(ranatt==8)printf("\nThe skeleton blocks your attack in a fancy skeleton way.\n");

      }
   	if(shp_2<=0)
   	{
         if(st<3)
      	printf("\n!!!|_The largest one of them is dead_|!!!\n");
      	getch();
   	}
   	if(shp_1<=0)
   	{
      	if(end==0) end++;
      	printf("\n!!!|_The smallest one of them is dead_|!!!\n");
      	getch();
   	}
      if(shp_1>0 && shp_2>0)
      {
         srand((unsigned)time(NULL));
      	ranatt3=rand()%4+1;
			if(ranatt3==1)printf("\nThe largest one swings his short sword at you.\n");
         if(ranatt3==2)printf("\nThe smallest one swings his short sword at you.\n");
         if(ranatt3==3)printf("\nThe largest one tries to run you through.\n");
         if(ranatt3==4)printf("\nThe smallest one tries to run you through.\n");
      }
      if(shp_1>0 && shp_2<=0) printf("\nThe smallest one swings his short sword at you.\n");
      if(shp_1<=0 && shp_2>0) printf("\nThe largest one falls appart.\n");

   	getch();
   	srand((unsigned)time(NULL));
		clhit=rand()%20+1;
   	monhit=th-clhit;
   	if(monhit<=loaded.armor && shp_1>0)
   	{
			srand((unsigned)time(NULL));
   		dam=rand()%6+1;
      	loaded.life-=dam;
			printf("\nYou were hit for %i Hit Points.\n",dam);
      	getch();
   	}
      else
      {
         if(shp_1>0 && shp_2>0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(shp_1>0 && shp_2<=0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(shp_1<=0 && shp_2>0)
         {
      		printf("\nYou wonder how many bones there are in that skeleton.\n");
         }
         else getch();
      }

      if(shp_2<=0)st+=2;
   	if(end==1) end++;
   	if(end>=2)
      {
         xc+=4;
      	hallway2();
		}
   	if(loaded.life<=0) pldeath();
	}
}
void hallway2(void)
{
   if(st>=3)
   {
		printf("\nYou defeated them!\n\n");
   	getch();
      loaded.xp+=130;
      hallway3();
   }
   else
   {
		printf("\n\nYou deafeated one of them, the other one just\n");
   	printf("falls appart on the floor.\n\n");
   	getch();
      loaded.xp+=65;
		hallway3();
   }
}
void pldeath(void)
{
   char answer;

   if(juju==0)
   {
		printf("\n\nAs you body falls to the ground, you black out and\n");
   	printf("feel nothing. As you'r soul starts his travel towards Valhall\n");
   	printf("the monsters continue they'r terror of The Land.\n");
   	getch();
   	printf("\nDo you want to play again\n");
		printf("\(Y/N\)?\n");
   	answer=toupper(getch());
   	switch(answer)
   	{
			case 'Y':
         	      system("start.exe");
                  exit(1);
      	case 'N':
      	         exit(1);
   	}
	}
   if(juju!=0)
   {
   	printf("\n\nThe Ju-Ju Zombie hits you for the last time, and your body falls to\n");
      printf("the ground as a heavy rock. You black out and your souls travel towards\n");
      printf("Valhall, the land of true wariors, has just begun.\n");
      printf("Meanwhile, the monsters continue to roam The Land.\n");
      getch();
   	printf("\n\nDo you want to play again\n");
		printf("\(Y/N\)?\n");
   	answer=toupper(getch());
   	switch(answer)
   	{
			case 'Y':
         	      system("start.exe");
                  exit(1);
      	case 'N':
      	         exit(1);
   	}
   }
}
void hallway3(void)
{
	printf("\n\nYou are in a long hallway that is about 2 meters to the north,\n");
	printf("5 meters to the west and 3 meters to the east.\n");
   printf("There are 3 doors at the north wall and one at the west wall.\n");
   printf("There is allso one door to the west on the south wall.\n");
   printf("And one door ca 1 meter to the east from that door on the south wall.\n");
   printf("The hallway is dirty, the floor is made of dirt and the walls\n");
   printf("are made of large stones.\n");
   printf("The walls are partly covered with dirt, and all the doors are made\n");
   printf("of wood\n");
   printf("You can:\n\n");
   printf("Walk through the door farthest west on the north wall(1)\n");
   printf("Walk through the door at the middle on the north wall(2)\n");
   printf("Walk through the door farthest to the east on the north wall(3)\n");
   printf("Walk through the door at the west end(4)\n");
   printf("Walk through the door farthest to the west on the south wall(5)\n");
   printf("Walk through the door farthest to the east on the south wall(6)\n");
   printf("Search the hallway for traps(7).\n");
   printf("Search the hallway for items(8).\n");
   printf("Get player stats(9)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)westroom();
   if(choice==2)midroom();
   if(choice==3)eastroom();
   if(choice==4)westdr();
   if(choice==5)storage();
   if(choice==6)main3();
   if(choice==7)traphallway();
   if(choice==8)search_hallway();
   if(choice==9)getplstat();
   if(choice==10)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }
   if(choice>10)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }

   hallway3();
}
void main3(void)
{
	printf("\n\nYou are in a dark room that is only lit by 2 torches.\n");
   printf("The walls are made of large stone blocks.\n");
   printf("The floor is made of dirt.\n");
	printf("The room is 6 meters to the north, and 4 meters to the east.\n");
   printf("There is one door at the middle of the north wall and one at\n");
   printf("the middle of the east wall.\n\n");
   printf("You can:\n\n");
	printf("Go through the east wall door(1)\n");
   printf("Go through the north wall door(2)\n");
   printf("Search for traps in this room(3)\n");
   printf("Search the room for any items(4)\n");
   printf("Get player Stats(5)\n");
   printf("Quit(6)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)loc();
   if(choice==2)
   {
   	if(tilbake==0)hallway3();
      if(tilbake==1)hallway4();
      if(tilbake==2)hallway5();
   }
   if(choice==3)trapmain();
   if(choice==4)searchmain2();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<0)
   {

	   printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }

   main2();
}
void westroom(void)
{
   tilbake=0;
	printf("\n\nYou are in a room that is 3 meters to the north and 3 meters\n");
   printf("to the east. The walls are made by small grey brick stones.\n");
   printf("A candle on the north wall lights the room. There are no windows here,\n");
   printf("and there is a bed at the north-west corner. There are some shelfes\n");
   printf("in the north-east corner. A dead rat lies by the north wall, between the\n");
   printf("shelfes and the bedroom.\n\n");
   printf("You can:\n\n");
	printf("Go back into the hallway(1)\n");
   printf("Smash the bed(2)\n");
   printf("Look for stuff in the shelfes(3)\n");
   printf("Search the room for traps(4)\n");
   printf("Search the room for items(5)\n");
   printf("Get player stats(6)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)hallway3();
   if(choice==2)smsbed();
   if(choice==3)wstrmshelfes();
   if(choice==4)wstrmtraps();
   if(choice==5)searchwstrm();
   if(choice==6)getplstat();
   if(choice==7)quit_a();
   if(choice<0)
   {

	   printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
   if(choice>7)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
westroom();
}
void smsbed(void)
{
	printf("\n\nYou draw you'r sword and smash the bed.\n");
   printf("The bed is all smashed up.\n");
   smash_1++;
   getch();
   westroom1();
}
void westroom1(void)
{
   tilbake=1;
	printf("\n\nYou are in a room that is 3 meters to the north and 3 meters\n");
   printf("to the east. The walls are made by small grey brick stones.\n");
   printf("A candle on the north wall lights the room. There are no windows here,\n");
   printf("and there is a bed at the north-west corner. There are some shelfes\n");
   printf("in the north-east corner. A dead rat lies by the north wall, between the\n");
   printf("shelfes and the bedroom.\n");
   if(smash_1==2)printf("The bed in the room is smashed.\n");
   printf("You can:\n\n");
	printf("Go back into the hallway(1)\n");
   printf("Look for stuff in the shelfes(2)\n");
   printf("Search the room for traps(3)\n");
   printf("Search the room for items(4)\n");
   printf("Get player stats(5)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)hallway4();
   if(choice==2)wstrmshelfes();
	if(choice==3)wstrmtraps();
   if(choice==4)searchwstrm();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<0)
   {

	   printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
westroom1();
}
void hallway4(void)
{
	printf("\n\nYou are in a long hallway that is about 2 meters to the north,\n");
	printf("5 meters to the west and 3 meters to the east.\n");
   printf("There are 3 doors at the north wall and one at the west wall.\n");
   printf("There is allso one door to the west on the south wall.\n");
   printf("And one door ca 1 meter to the east from that door on the south wall.\n");
   printf("The hallway is dirty, the floor is made of dirt and the walls\n");
   printf("are made of large stones.\n");
   printf("The walls are partly covered with dirt, and all the doors are made\n");
   printf("of wood\n");
   printf("You can:\n\n");
   printf("Walk through the door farthest west on the north wall(1)\n");
   printf("Walk through the door at the middle on the north wall(2)\n");
   printf("Walk through the door farthest to the east on the north wall(3)\n");
   printf("Walk through the door at the west end(4)\n");
   printf("Walk through the door farthest to the west on the south wall(5)\n");
   printf("Walk through the door farthest to the east on the south wall(6)\n");
   printf("Search the hallway for traps(7).\n");
   printf("Search the hallway for items(8).\n");
   printf("Get player stats(9)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)westroom1();
   if(choice==2)midroom();
   if(choice==3)eastroom();
   if(choice==4)westdr();
   if(choice==5)storage();
   if(choice==6)main3();
   if(choice==7)traphallway();
   if(choice==8)search_hallway();
   if(choice==9)getplstat();
   if(choice==10)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }
   if(choice>10)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }
hallway4();
}
void wstrmshelfes(void)
{

	printf("\nIn the shelfes you find a key, and 15 Gold Coins in a belt pouch.\n");
   loaded.gp+=15;
   key=1;
   getch();
westroom2();
}
void westroom2(void)
{
   tilbake=2;
	printf("\n\nYou are in a room that is 3 meters to the north and 3 meters\n");
   printf("to the east. The walls are made by small grey brick stones.\n");
   printf("A candle on the north wall lights the room. There are no windows here,\n");
   printf("and there is a bed at the north-west corner. There are some shelfes\n");
   printf("in the north-east corner. A dead rat lies by the north wall, between the\n");
   printf("shelfes and the bed.\n");
   if(smash_1==2)printf("The bed in the room is smashed.\n");
   printf("You can:\n\n");
	printf("Go back into the hallway(1)\n");
   printf("Search the room for traps(2)\n");
   printf("Search the room for items(3)\n");
   printf("Get player stats(4)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)hallway5();
	if(choice==2)wstrmtraps();
   if(choice==3)searchwstrm();
   if(choice==4)getplstat();
   if(choice==5)quit_a();
   if(choice<0)
   {

	   printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
   if(choice>5)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
westroom2();
}
void hallway5(void)
{
	printf("\n\nYou are in a long hallway that is about 2 meters to the north,\n");
	printf("5 meters to the west and 3 meters to the east.\n");
   printf("There are 3 doors at the north wall and one at the west wall.\n");
   printf("There is allso one door to the west on the south wall.\n");
   printf("And one door ca 1 meter to the east from that door on the south wall.\n");
   printf("The hallway is dirty, the floor is made of dirt and the walls\n");
   printf("are made of large stones.\n");
   printf("The walls are partly covered with dirt, and all the doors are made\n");
   printf("of wood\n");
   printf("You can:\n\n");
   printf("Walk through the door farthest west on the north wall(1)\n");
   printf("Walk through the door at the middle on the north wall(2)\n");
   printf("Walk through the door farthest to the east on the north wall(3)\n");
   printf("Walk through the door at the west end(4)\n");
   printf("Walk through the door farthest to the west on the south wall(5)\n");
   printf("Walk through the door farthest to the east on the south wall(6)\n");
   printf("Search the hallway for traps(7).\n");
   printf("Search the hallway for items(8).\n");
   printf("Get player stats(9)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)westroom2();
   if(choice==2)midroom();
   if(choice==3)eastroom();
   if(choice==4)westdr();
   if(choice==5)storage();
   if(choice==6)main3();
   if(choice==7)traphallway();
   if(choice==8)search_hallway();
   if(choice==9)getplstat();
   if(choice==10)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }
   if(choice>10)
   {
   	printf("\nChoices must range from 1 to 9.\n");
      getch();
   }
hallway5();
}
void exroom(void)
{
	printf("\n\nYou are in a room that is 3 meters to the north, 3 meters to the south\n");
   printf("(from the west wall door) and 5 meters to the east.\n");
   printf("At the middle of the east wall door is there a large metal door.\n");
   printf("It is 3 meters wide and 5 meters tall. On each side of the door\n");
   printf("are there two statues standing. This door looks like the entrance to this place.\n");
   printf("With other words, the exit to it.\n");
   printf("You can:\n\n");
   printf("(1)Walk towards the large east wall door.\n");
   printf("(2)Walk through the west wall door.\n");
   printf("(3)Search the room for items.\n");
   printf("(4)Search the room for traps.\n");
   printf("(5)Get player stats.\n");
   choice=atoi(gets(chooce));
   if(choice==1)estgolems();
   if(choice==2)loc();
   if(choice==3)glmitm();
   if(choice==4)rmtraps();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
exroom();
}
void wstrmtraps(void)
{
	printf("\nHit a key to see if you find any traps.\n");
   getch();
	printf("\nYou didn't find any traps.\n");
   getch();
	if(tilbake==0)westroom();
   if(tilbake==1)westroom1();
   if(tilbake==2)westroom2();
}
void searchwstrm(void)
{
   int continc;
	printf("Hit a key to see if you find anything:");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%10+1+loaded.findchance;
   if(find>7 && cont<=1)   // && is logical 'and'
   {
   	printf("\nYou found 40 Gold coins in a secret container under the dirt floor.\n");
      loaded.gp+=40;
      continc=1;
      getch();
   }
   if(find<=7 || cont==2)   // || is logical 'or'
   {
   	printf("\nYou didn't find anything.\n");
      getch();
	}
	if(cont!=1 && cont!=2)
   {
   	printf("\nYou didn't find anything.\n");
      getch();
	}
   if(continc==1)
   {
   	cont++;
   	continc--;
   }
   if(tilbake==0)westroom();
   if(tilbake==1)westroom1();
   if(tilbake==2)westroom2();
}
void midroom(void)
{
	printf("\n\nYou enter a dark room not lighted by anything else than the\n");
   printf("the moonlight from a window on the north wall. The room is 2 meters\n");
   printf("to the north, 1 meter to the west(from the door that leads to \n");
   printf("the hallway), and 1 meter to the east.\n");
   printf("The window is blocked by steal bars.\n");
   printf("The walls are made of grey brick stones. And the room is totally empty\n");
   printf("You can:\n\n");
   printf("Go back to the hallway(1)\n");
   printf("Get player stats(2)\n\n");

   choice=atoi(gets(chooce));
   if(choice==1)
   {
    	if(tilbake==0)hallway3();
   	if(tilbake==1)hallway4();
   	if(tilbake==2)hallway5();

   }
   if(choice==2)getplstat();
   if(choice==3)quit_a();

   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 2.\n");
      getch();
   }
   if(choice>3)
   {
   	printf("\nChoices must range from 1 to 2.\n");
      getch();
   }
midroom();
}
void eastroom(void)
{
	printf("\n\nYou are in a room that is 2 meters to the north,\n");
   printf("1 meter to the west, and 1 meter the the east(from the door that\n");
   printf("leads to the hallway). The wall is made of greyish brick stones,\n");
   printf("There is a window blocked by steel bars at the middle of the north wall.\n");
   printf("The room is only lighted by the moonlight that comes from outside\n");
   printf("the window. It is fullmoon.\n");
   printf("In the north west corner of the room is there a small wood table.\n");
   printf("On the table lies a potion of something. It looks red-greensish and\n");
   printf("smells funny. There is a small paper piece attached to the potion.\n");
   printf("It says: \"Health\"\n");
   printf("You can:\n\n");
   printf("Drink the potion(1)\n");
   printf("Go back into the hallway(2)\n");
   printf("Get player stats(3)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)ption();
   if(choice==2)
   {
    	if(tilbake==0)hallway3();
   	if(tilbake==1)hallway4();
   	if(tilbake==2)hallway5();
   }
   if(choice==3)getplstat();
   if(choice==4)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
eastroom();
}
void ption(void)
{
	printf("\nYou drink the potion and feel much stronger.\n");
   loaded.life+=14;
   getch();
   eastroom1();
}
void eastroom1(void)
{
	printf("\n\nYou are in a room that is 2 meters to the north,\n");
   printf("1 meter to the west, and 1 meter the the east(from the door that\n");
   printf("leads to the hallway). The wall is made of greyish brick stones,\n");
   printf("There is a window blocked by steel bars at the middle of the north\n");
   printf("wall. The room is only lighted by the moonlight that comes from\n");
   printf("outside the window. It is fullmoon.\n");
   printf("In the north west corner of the room is there a small wood table.\n");
   printf("You can:\n\n");
   printf("Go back into the hallway(1)\n");
   printf("Get player stats(2)\n");
   printf("Search the room for items(3)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)
   {
    	if(tilbake==0)hallway3();
   	if(tilbake==1)hallway4();
   	if(tilbake==2)hallway5();
   }
   if(choice==2)getplstat();
   if(choice==3)estitm();
   if(choice==4)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
eastroom1();
}
void estitm(void)
{
	printf("\n\nHit a button to see if you find anything.\n ");
   getch();
   srand((unsigned)time(NULL));
	find=rand()%15+1+loaded.findchance;
   if(all_i==1 && find>=13)
   {
   	printf("You found 5 Gold Coins.\n");
      loaded.gp+=5;
      all_i+=1;
      getch();
      eastroom1();
   }
   else printf("You didn't find anything.\n");
   getch();
   eastroom1();
}
void traphallway(void)
{
	printf("\n\nHit a key to see if you find any traps.\n");
   getch();
   srand((unsigned)time(NULL));
	find=rand()%14+1+loaded.findchance;
   if(trap==1 && find>11)
   {
   	printf("\n\nYou found a trap over the west door on the south wall.\n");
      printf("It was designed so that 3 blades would run you through from above\n");
      printf("when you walked through the door. You successfuly disabled it.\n");
      trap+=2;
      getch();
      if(tilbake==0)hallway3();
   	if(tilbake==1)hallway4();
   	if(tilbake==2)hallway5();
   }
   else
   {
		printf("You didn't find anything.\n");
      getch();
   }
}
void search_hallway(void)
{
	printf("\n\nHit a key to see if you find any items.\n");
   getch();
	printf("You didn't find anything.\n");
   getch();
   if(tilbake==0)hallway3();
   if(tilbake==1)hallway4();
   if(tilbake==2)hallway5();
}
void westdr(void)
{
   if(gkey==1)
   {
   	printf("\nThe door is locked, and the keyhole looks strange.\n");
      getch();
      if(tilbake==0)hallway3();
	   if(tilbake==1)hallway4();
   	if(tilbake==2)hallway5();
   }
   if(gkey==2)wstdrent();
}
void storage(void)
{
   int dm;
   int ent=1;

   if(trap==1)
   {
   	printf("As you enter the room, 3 blades run you through from above\n");
      printf("(in the doorway).\n");
      getch();
      srand((unsigned)time(NULL));
      dm=rand()%21+1;
      printf("\nYou were hit for %i Hit Points.\n", dm);
      loaded.life-=dm;
		getch();
      trap++;
		if(loaded.life<=0)pldeath();

   }
   if(trap==2 || ent==1 && zdeath==0)
   {
		printf("\n\nYou are in a room that is 4 meters to the south.\n");
   	printf("1 meter to the west(from the door you just entered) and 1 meter to\n");
   	printf("the east(the door is 1 meter wide). The walls are made of\n");
   	printf("large stones and are abit wet. A wooden 1/2x1/2 meter table\n");
   	printf("is in the middle if the room. The room is lighted by two torches,\n");
   	printf("1 at the east wall, and one at the west wall. Some rotten remains of\n");
   	printf("food are scattered around. Two zombies are standing at the south wall.\n");
   	printf("At the middle of the south wall is there a door made of wood.\n");
      printf("Each zombie has a small steel shield.\n");
   	printf("They look as if they are guarding the door.\n");
      printf("They notice you and come walking against you.\n");
   }
   else storage1();

   printf("You can:\n\n");
   printf("Attack(1)\n");
   printf("Flee(2)\n");
   printf("Get player stats(3)\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)att_2();
   if(choice==2)flee_3();
   if(choice==3)getplstat();
   if(choice==4)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
storage();
}
void att_2(void)
{
   unsigned int plhit,monhit,clhit,tpmon,dam,xc; //tpmon is used for which of them you hit
   int th=19;
   int ac=8;
   int ranatt;
   int ranatt2;
   int ranatt3;
   int ranatt4;
   int first=1;
   unsigned int end=0;
   unsigned int endb=0;

   for(xc=0;xc<2;)
   {
      if(first==1)
      {
			printf("\n\nYou raise you'r sword and attack.\n");
   		printf("Hit a button to see if you hit.\n");
      	first++;
   		getch();
      }
      else
      {
      	srand((unsigned)time(NULL));
      	ranatt2=rand()%11+1;
			if(ranatt2==1)printf("\nYou swing you'r sword in a attempt to cut the zombies head off.\n");
      	if(ranatt2==2)printf("\nYou try to cut the zombie in half from above.\n");
      	if(ranatt2==3)printf("\nYou swing you'r sword in a hope to fatally damage the zombie.\n");
      	if(ranatt2==4)printf("\nYou try to cut the zombie in half through his rotten guts.\n");
      	if(ranatt2==5)printf("\nYou try to cut off his right arm.\n");
      	if(ranatt2==6)printf("\nYou try to cut off his leg.\n");
      	if(ranatt2==7)printf("\nYou go berserk and raise your sword in a wild attack.\n");
      	if(ranatt2==8)printf("\nYou just swing your sword at the zombies in a hope of hitting.\n");
         if(ranatt2==9)printf("\nYou try to cut off his left arm.\n");
         if(ranatt2==10)printf("\nYou try to run the zombie through.\n");
         if(ranatt2==11)printf("\nYou swing you'r sword at the zombies as hard as you can.\n");
         printf("Hit a button to see if you hit.\n");
         getch();
      }
   	srand((unsigned)time(NULL));
   	clhit=rand()%20+1;
   	plhit=loaded.thaco-clhit;
   	if(plhit<=ac)
   	{
      	srand((unsigned)time(NULL));
      	tpmon=rand()%10+1;
      	if(tpmon<=5 && zhp_1>0)
      	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		zhp_1-=dam;
         	printf("\nYou hit the most stinky one of them for %i Hit Points.\n",dam);
         	getch();
			}
			if(tpmon>=6)
      	{
         	if(st2<3)
         	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		zhp_2-=dam;
         	printf("\nYou hit the uggliest one of them for %i Hit Points.\n",dam);
         	getch();
				}
            else printf("\nYou totally missed dude!\n");
			}
         else printf("\nThat was a total miss dude!\n");
		}
   	else
      {
         srand((unsigned)time(NULL));
         ranatt=rand()%9+1;
			if(ranatt==1)printf("\nYou didn't hit.\n");
         if(ranatt==2)printf("\nThe zombie blocks your attack with his small shield.\n");
         if(ranatt==3)printf("\nThe zombie dodges your attack.\n");
         if(ranatt==4)printf("\nYou miss the zombie with a inch.\n");
         if(ranatt==5)printf("\nThe zombie leaps to the leaft, away from your attack.\n");
         if(ranatt==6)printf("\nYou miss and your sword allmost falls out of your hands.\n");
         if(ranatt==7)printf("\nYou simply miss.\n");
         if(ranatt==8)printf("\nThe zombie blocks your attack with his shield in a groovie zombie way.\n");
         if(ranatt==9)printf("\nThe zombie blocks your attack with his shield in a groovie Ninja way.\n");
      }
   	if(zhp_2<=0 && endb==0)
   	{
         if(st2<3)
         endb++;
      	printf("\n!!!|_The uggliest one of them is dead_|!!!\n");
      	getch();
   	}
   	if(zhp_1<=0 && end==0)
   	{
      	end++;
      	printf("\n!!!|_The most stinky one of them is dead_|!!!\n");
      	getch();
   	}
      if(zhp_1>0 && zhp_2>0)
      {
         srand((unsigned)time(NULL));
      	ranatt3=rand()%4+1;
			if(ranatt3==1)printf("\nThe uggliest one swings his uggly fist at you.\n");
         if(ranatt3==2)printf("\nThe most stinky one swings his stinky fist at you.\n");
         if(ranatt3==3)printf("\nThe uggliest one tries to run you through with his bare hands.\n");
         if(ranatt3==4)printf("\nThe most stinky one tries to run you through with his stinky bare hands.\n");
      }
      if(zhp_1>0 && zhp_2<=0) printf("\nThe most stinky one swings his fist at you.\n");
      if(zhp_1<=0 && zhp_2>0)
      {
         srand((unsigned)time(NULL));
      	ranatt4=rand()%4+1;
      	if(ranatt4==1)printf("\nThe uggliest one attacks you in a uggly rage.\n");
         if(ranatt4==2)printf("\nThe uggliest one tries to run you through with his uggly hands.\n");
         if(ranatt4==3)printf("\nThe uggliest one swings his uggly fist at you.\n");
         if(ranatt4==4)printf("\nThe uggliest one tries to brake your nose.\n");
         getch();
      }
		getch();
   	srand((unsigned)time(NULL));
		clhit=rand()%20+1;
   	monhit=th-clhit;
   	if(monhit<=loaded.armor && zhp_1>0)
   	{
			srand((unsigned)time(NULL));
   		dam=rand()%8+1;
      	loaded.life-=dam;
			printf("\nYou were hit for %i Hit Points.\n",dam);
      	getch();
   	}
      else
      {
         if(zhp_1>0 && zhp_2>0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(zhp_1>0 && zhp_2<=0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(zhp_1<=0 && zhp_2<=0)
         {
      		printf("\nPhef, stinky and uggly are dead.\n");
         }
         if(zhp_1<=0 && zhp_2>0)
         {
      		printf("\nHe didn't hit.\n");
         }
			else getch();
         getch();
      }

      if(zhp_2<=0)st2+=2;
   	if(end==1 && endb==1) end++;
   	if(end>=2)
      {
         xc+=4;
         zdeath=1;
      	storage1();
      }
   	if(loaded.life<=0) pldeath();
	}
}
void storage1(void)
{

   if(xputd==0)
   {
   	if(zhp_1<=0 && zhp_2<=0)loaded.xp+=130;
   	xputd+=2;
   }
	printf("\n\nYou are in a room that is 4 meters to the south.\n");
   printf("1 meter to the west(from the door you just entered) and 1 meter to\n");
 	printf("the east(the door is 1 meter wide). The walls are made of\n");
  	printf("large stones and are abit wet. A wooden 1/2x1/2 meter table\n");
  	printf("is in the middle if the room. The room is lighted by two torches,\n");
  	printf("one at the east wall, and one at the west wall. Some rotten remains of\n");
  	printf("food are scattered around. Two dead zombies lie on the floor.\n");
   printf("There is a wooden door on the middle of the south wall.\n");
   printf("You can:\n\n");
   printf("(1)Walk through the door at the north wall(to the hallway).\n");
   printf("(2)Walk through the door at the south wall.\n");
   printf("(3)Searh the room for items.\n");
   printf("(4)Searh the room for traps.\n");
   printf("(5)Get player stats.\n\n");
   choice=atoi(gets(chooce));
   if(choice==1)
   {
   	if(tilbake==0)hallway3();
		if(tilbake==1)hallway4();
      if(tilbake==2)hallway5();
   }
   if(choice==2)strsthdr();
   if(choice==3)storageitems();
   if(choice==4)storagetraps();
   if(choice==5)getplstat();
   if(choice==6)quit_a();
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 5.\n");
      getch();
   }
storage1();
}
void flee_3(void)
{
	printf("\n\nYou flee out of this room, back into the hallway.\n");
   printf("The zombies stay where they are, and don't follow.\n");
	getch();
   if(tilbake==0)hallway3();
   if(tilbake==1)hallway4();
   if(tilbake==2)hallway5();
}
void storagetraps(void)
{
	printf("\n\nHit a key to see if you find any traps.\n");
   getch();
   printf("You didn't find any traps.\n");
   getch();
   storage1();
}
void storageitems(void)
{
  printf("\n\nHit a key to see if you find anything.\n");
  getch();
  srand((unsigned)time(NULL));
  find=rand()%10+1;
  if(gpfind==0)
  {
  		if(find>=8)
  		{
  			printf("You found 7 Gold Coins among the\n");
         printf("rotten remains of food scattered around the room.\n");
         getch();
      	loaded.gp+=7;
      	gpfind+=2;
  		}
  }
  if(gpfind2==0)
  {
  		if(find<8)
  	  	{
     		printf("You found 10 Gold Coins in a belt pouch on one of the zombies.\n");
         getch();
			loaded.gp+=10;
  	   	gpfind2+=2;
      }
  }
  if(find<8 && gpfind2!=0)printf("You didn't find anything.\n");
  if(find>=8 && gpfind!=0)printf("You didn't find anything.\n");
  else printf("You didn't find anything.\n");
  getch();
}
void strsthdr(void)
{
	printf("\n\nThe room you are on looks like this;\n");
   printf(" 1 meter on each side of door. \n");
   printf("    -- D --\\ \n");
   printf("    |       \\ \n");
   printf("4m  |        D     5 meters long wall\n");
   printf("    |         \\ \n");
   printf("    |__________\\ \n");
	printf("       5m\n\n");
   printf("D = door.\n");
   printf("The room looks like a kitchen, or what once was a kitchen.\n");
   printf("There are just tables, and broken chairs scattered all over the place.\n");
   printf("This place smells funny. The walls are made of large stones\n");
   printf("and are very dirty. All the doors in this room are made of wood\n");
   printf("There is one at the middle of the east wall.\n");
   printf("And one at the middle of the north wall.\n");
   printf("\nYou can:\n\n");
   printf("(1)Walk through the north wall door.\n");
   printf("(2)Walk through the east wall door.\n");
   printf("(3)Search the room for items.\n");
   printf("(4)Search the room for traps.\n");
   printf("(5)Get player stats.\n");
   choice=atoi(gets(chooce));
   if(jhp>0)
   {
   	if(choice==1)storage1();
   	if(choice==2)
      {
      	if(jhp>0)bossroom();
         if(jhp<=0)bossdead();
      }
   	if(choice==3)search_kitchen();
   	if(choice==4)traps_kitchen();
   	if(choice==5)getplstat();
   	if(choice==6)quit_a();
   }
   if(jhp<=0)
   {
      if(choice==1)storage1();
   	if(choice==2)bossdead();
   	if(choice==3)search_kitchen();
   	if(choice==4)traps_kitchen();
   	if(choice==5)getplstat();
   	if(choice==6)quit_a();
   }
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
   if(choice>6)
   {
   	printf("\nChoices must range from 1 to 6.\n");
      getch();
   }
strsthdr();
}
void search_kitchen(void)
{
   int get,hit,dam;

	printf("\n\nHit a key to see if you find anything in this mess.\n");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%10+1+loaded.findchance;
   if(find>=8 && kitchenfinder==0 && kchtrap!=1)
   {
   	printf("\n\nYou found a healing potion.\n");
		printf("You drink it and feel much stronger.\n");
      getch();
      get=find*2;
      loaded.life+=get;
      kitchenfinder++;
   }
   if(find<8 && kchtrap!=1)
	{
   	printf("You didn't find anything.\n");
      getch();
   }
   if(kchtrap==1)
   {
		printf("\n\nAs you look around for items in the room,\n");
      printf("you see a stone in the dirt floor. There are some strange\n");
      printf("letters, or forms carved into the small stone. As you pick the stone up,\n");
      printf("it triggers a trap, and a arrow shoots out from a crack in the south wall\n");
      printf("straight at you.\n");
      printf("Hit a key to see if you get hit.\n");
      getch();
      kchtrap++;
      srand((unsigned)time(NULL));
      hit=rand()%20+1;
      if(hit<=5)
      {
         srand((unsigned)time(NULL));
      	dam=rand()%8+1;
      	printf("You were hit for %i Hit Points",dam);
         loaded.life-=dam;
      }
      if(hit>5)printf("\n\nYou manage to jump aside avoiding the arrow. The arrow hits the north stone wall\n");
   	getch();
   }
strsthdr();
}
void traps_kitchen(void)
{
	printf("\n\nHit a button to see if you find any traps.\n");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%10+1+loaded.findchance;
   if(find>=8 && kchtrap==1)
   {
   	printf("\n\nYou found a stone that triggers a trap in the south wall.\n");
      printf("A arrow would shoot through a crack in the wall if you picked up\n");
      printf("the stone. You successfully disarmed the trap.\n");
      kchtrap++;
   }
   if(find<8 && kchtrap!=1) printf("You didn't find anything.\n");
   getch();
strsthdr();
}
void bossroom(void)
{
	printf("\n\nYou are in a room that looks like this:\n");
   printf("        5m       \n");
	printf("   \\----------| \n");
   printf("    \\         | \n");
   printf("     D         | 4m\n");
   printf(" 5m   \\       | \n");
   printf("       \\______| \n");
   printf("          3m");
   printf("\n D = Door\n");
   printf("\nThe room is dirty. The walls are made of large stones.\n");
   printf("The room is totally empty, except from 1 yellow\n");
   printf("ju-ju zombie in the middle of it. He sees you and attacks.\n");
   printf("He is holding a small shield.\n");
   printf("You have no chance of getting away.\n");
   printf("You can:\n\n");
   printf("(1)Attack.\n");
   printf("(2)Get player status.\n");
   printf("(3)Commit suicide.\n");
   choice=atoi(gets(chooce));
   if(choice==1)jujuatt();
   if(choice==2)getplstat();
   if(choice==3)pldeath();
   if(choice==4)exit(1);
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
bossroom();
}
void jujuatt(void)
{
   unsigned int plhit,monhit,clhit,dam,xc;
   int th=15;
   int ac=6;
   int ranatt;
   int ranatt2;
   int ranatt3;
   int first=1;
   unsigned int end=0;

   for(xc=0;xc<2;)
   {
      if(first==1)
      {
			printf("\n\nYou raise you'r sword and attack.\n");
   		printf("Hit a button to see if you hit.\n");
      	first++;
   		getch();
      }
      else
      {
      	srand((unsigned)time(NULL));
      	ranatt2=rand()%11+1;
			if(ranatt2==1)printf("\nYou swing your sword in a attempt to cut the zombie's head off.\n");
      	if(ranatt2==2)printf("\nYou try to cut the zombie in half from above.\n");
      	if(ranatt2==3)printf("\nYou swing your sword in a hope to fatally damage the zombie.\n");
      	if(ranatt2==4)printf("\nYou try to cut the zombie in half through his rotten guts.\n");
      	if(ranatt2==5)printf("\nYou try to cut off his right arm.\n");
      	if(ranatt2==6)printf("\nYou try to cut off his leg.\n");
      	if(ranatt2==7)printf("\nYou go berserk and raise your sword in a wild attack.\n");
      	if(ranatt2==8)printf("\nYou just swing your sword at the zombie's in a hope of hitting.\n");
         if(ranatt2==9)printf("\nYou try to cut off his left arm.\n");
         if(ranatt2==10)printf("\nYou try to run the zombie through.\n");
         if(ranatt2==11)printf("\nYou swing you'r sword at the zombie's as hard as you can.\n");
         printf("Hit a button to see if you hit.\n");
         getch();
      }
   	srand((unsigned)time(NULL));
   	clhit=rand()%20+1;
   	plhit=loaded.thaco-clhit;
   	if(plhit<=ac)
   	{
       	srand((unsigned)time(NULL));
      	dam=rand()%8+1;
     		jhp-=dam;
        	printf("\nYou hit the horrible ju-ju zombie for %i Hit Points.\n",dam);
        	getch();
      }
   	if(plhit>ac)
      {
         srand((unsigned)time(NULL));
         ranatt=rand()%10+1;
			if(ranatt==1)printf("\nYou didn't hit.\n");
         if(ranatt==2)printf("\nThe ju-ju zombie blocks your attack with his small shield.\n");
         if(ranatt==3)printf("\nThe ju-ju zombie dodges your attack.\n");
         if(ranatt==4)printf("\nYou miss the ju-ju zombie with a inch.\n");
         if(ranatt==5)printf("\nThe ju-ju zombie leaps to the leaft, away from your attack.\n");
         if(ranatt==6)printf("\nYou miss and your sword allmost falls out of your hands.\n");
         if(ranatt==7)printf("\nYou simply miss.\n");
         if(ranatt==8)printf("\nThe ju-ju zombie blocks your attack with his shield in a groovie zombie way.\n");
         if(ranatt==9)printf("\nThe ju-ju zombie blocks your attack with his shield in a groovie Ninja way.\n");
         if(ranatt==9)printf("\nThe ju-ju zombie moves away from your attack fast enough to not get hit.\n");
         getch();
      }
   	if(jhp<=0)
   	{
      	end++;
      	printf("\nThe horrible ju-ju zombie falls to the ground and exhales heavily, the zombie is dead!\n");
      	getch();
   	}
      if(jhp>0)
      {
         srand((unsigned)time(NULL));
      	ranatt3=rand()%8+1;
			if(ranatt3==1)printf("\nThe ju-ju zombie swings his uggly fist at you.\n");
         if(ranatt3==2)printf("\nThe ju-ju zombie swings his stinky fist at you.\n");
         if(ranatt3==3)printf("\nThe ju-ju zombie tries to run you through with his bare hands.\n");
         if(ranatt3==4)printf("\nThe ju-ju zombie tries to run you through with his stinky bare hands.\n");
         if(ranatt3==5)printf("\nThe ju-ju zombie attacks you in a uggly rage.\n");
         if(ranatt3==6)printf("\nThe ju-ju zombie tries to run you through with his uggly hands.\n");
         if(ranatt3==7)printf("\nThe ju-ju zombie swings his uggly fist at you.\n");
         if(ranatt3==8)printf("\nThe ju-ju zombie tries to brake your nose.\n");

      }
      getch();

   	srand((unsigned)time(NULL));
		clhit=rand()%20+1;
   	monhit=th-clhit;
   	if(monhit<=loaded.armor && jhp>0)
   	{
			srand((unsigned)time(NULL));
   		dam=rand()%10+3;
      	loaded.life-=dam;
			printf("\nYou were hit for %i Hit Points.\n",dam);
         getch();
      }
      else
      {
         if(jhp>0 && monhit>loaded.armor)
         {
         	srand((unsigned)time(NULL));
         	ranatt=rand()%10+1;
				if(ranatt==1)printf("\nThe ju-ju zombie didn't hit.\n");
         	if(ranatt==2)printf("\nYou block the ju-ju zombie's attack with your sword.\n");
         	if(ranatt==3)printf("\nYou dodge the ju-ju zombie's attack.\n");
         	if(ranatt==4)printf("\nThe ju-ju zombie misses you with a inch.\n");
         	if(ranatt==5)printf("\nYou manage to leap away from the horrible ju-ju zombies attack.\n");
         	if(ranatt==6)printf("\nYou block the horrible ju-ju zombie's powerful attack.\n");
         	if(ranatt==7)printf("\nThe ju-ju zombie simply misses.\n");
         	if(ranatt==8)printf("\nYou block the ju-ju zombie's attack with your sword in a groovie warior way.\n");
         	if(ranatt==9)printf("\nYou block the ju-ju zombie's attack with your sword in a groovie gangsta' way.\n");
         	if(ranatt==9)printf("\nYou move away from the ju-ju zombie's attack fast enough to not get hit.\n");
         }
         if(jhp<=0)
         {
      		printf("\nYou killed the horrible ju-ju zombie. He is dead!\n");
         }
         getch();
      }
   	if(end==1) end++;
   	if(end>=2)
      {
         xc+=4;
      	bossdead();
      }
   	if(loaded.life<=0)
      {
			juju++;
      	pldeath();
      }
	}
}
void bossdead(void)
{
   if(juxp==0)
   {
   	loaded.xp+=975;
      juxp++;
   }
   if(loaded.xp>=loaded.nextlev)
   {
   	nextlev_b();
   }
   printf("\n\nYou are in a room that lookes like this:\n");
   printf("        5m       \n");
	printf("   \\----------| \n");
   printf("    \\         | \n");
   printf("     D         | 4m\n");
   printf(" 5m   \\       | \n");
   printf("       \\______| \n");
   printf("          3m");
   printf("\n D = Door\n");
   printf("\nThe room is dirty. The walls are made of large stones.\n");
   printf("The room is totally empty, except from one dead ju-ju zombie,\n");
   printf("wich is lying in the middle of the room. There is one\n");
   printf("door at the west wall, leading towards something that once was a kitchen.\n");
   printf("You can:\n\n");
   printf("(1)Walk through the west wall door.\n");
   printf("(2)Search for items in the room.\n");
   printf("(3)Search for traps.\n");
   printf("(4)Get player status.\n");
   choice=atoi(gets(chooce));
   if(choice==1)strsthdr();
   if(choice==2)bossitm();
   if(choice==3)bosstraps();
   if(choice==4)getplstat();
   if(choice==5)exit(1);
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 4.\n");
      getch();
   }
   if(choice>5)
   {
   	printf("\nChoices must range from 1 to 4.\n");
      getch();
   }
   getch();
bossdead();
}
void nextlev_b(void)
{
  int done;
  int plus;
  done=FALSE;

  if(loaded.xp>=loaded.nextlev)
  {
     while(!done)
     {
     		if(loaded.nextlev>=950)
         {
	         loaded.nextlev*=2;
            srand((unsigned)time(NULL));
            plus=rand()%10+3;
            loaded.life+=plus;
            loaded.medlife+=plus;
            printf("You rose to level 2 for wariors.\n");
            getch();
            done=TRUE;
            break;
         }
         if(loaded.nextlev>=1900)
         {
	         loaded.nextlev*=2;
            srand((unsigned)time(NULL));
            plus=rand()%10+3;
            loaded.life+=plus;
            loaded.medlife+=plus;
            printf("You rose to level 3 for wariors.\n");
            getch();
            done=TRUE;
            break;
         }
     }
  	}
   if(loaded.xp<loaded.nextlev && done==FALSE)
   {
   	printf("\n\nSorry dude! You didn't rise in levels this time.\n");
      getch();
   }
}
void bosstraps(void)
{
	printf("\n\nHit a button to see if you find any traps.\n");
   getch();
   printf("You didn't find any traps.\n");
   getch();
bossdead();
}
void bossitm(void)
{
	printf("\n\nHit a button to see if you find anything.\n");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%15+1;
   if(find>=10 && gkey==1)
   {
   	printf("\nYou found a strange key, in one of the zombies pockets.\n");
      gkey++;
      getch();
   }
   if(find<10)
   {
   	printf("You didn't find anything.\n");
      getch();
   }
bossdead();
}
void wstdrent(void)
{
	printf("\n\nYou are in a 3 by 3 meters large room filled with gold and jewels.\n");
   printf("You are rich!!\n");
   printf("But you will never be able to carry this back to town by yourself.\n");
   printf("So you decide to lock the door and come and get the tresure later.\n");
   getch();
   printf("You step out into the hallway and lock the door, after filling your.\n");
   printf("pockets with Gold coins.\n");
   loaded.gp+=700;
   getch();
   if(tilbake==0)hallway3();
   if(tilbake==1)hallway4();
   if(tilbake==2)hallway5();
}
void rmtraps(void)
{
	printf("\n\nHit a key to see if you find any traps.\n");
   getch();
   printf("You didn't find anything.\n");
   getch();
}
void glmitm(void)
{
	printf("\n\nHit a key to see if you find anything.\n");
   getch();
   srand((unsigned)time(NULL));
   find=rand()%15+1+loaded.findchance;
   if(find>11 && glm<2)
   {
   	printf("You found 1 Gold Coin in the north-west corner of the room.\n");
      glm++;
      loaded.gp++;
      getch();
   }
   if(find<=11)
   {
   	printf("You didn't find anything.\n");
      getch();
   }
}
void estgolems(void)
{
   unsigned int plhit,monhit,clhit,tpmon,dam,xc; //tpmon is used for wich of them you hit
   int th=16;
   int ac=3;
   int ranatt;
   int ranatt2;
   int ranatt3;
   int ranatt4;
   int first=1;
   unsigned int end=0;
   unsigned int endb=0;

   printf("As you walk towards the golems, the suddenly attack you.\n");
   getch();
   clrscr();
   for(xc=0;xc<2;)
   {
      if(first==1)
      {
			printf("\n\nYou raise you'r sword and attack.\n");
   		printf("Hit a button to see if you hit.\n");
      	first++;
   		getch();
      }
      else
      {
      	srand((unsigned)time(NULL));
      	ranatt2=rand()%11+1;
			if(ranatt2==1)printf("\nYou swing you'r sword in a attempt to cut the golems head off.\n");
      	if(ranatt2==2)printf("\nYou try to cut the golem in half from above.\n");
      	if(ranatt2==3)printf("\nYou swing you'r sword in a hope to fatally damage the golem.\n");
      	if(ranatt2==4)printf("\nYou try to cut the golem in half through his guts.\n");
      	if(ranatt2==5)printf("\nYou try to cut off his right arm.\n");
      	if(ranatt2==6)printf("\nYou try to cut off his leg.\n");
      	if(ranatt2==7)printf("\nYou go berserk and raise your sword in a wild attack.\n");
      	if(ranatt2==8)printf("\nYou just swing your sword at the golems in a hope of hitting.\n");
         if(ranatt2==9)printf("\nYou try to cut off his left arm.\n");
         if(ranatt2==10)printf("\nYou try to run the golem through.\n");
         if(ranatt2==11)printf("\nYou swing you'r sword at the golem as hard as you can.\n");
         printf("Hit a button to see if you hit.\n");
         getch();
      }
   	srand((unsigned)time(NULL));
   	clhit=rand()%20+1;
   	plhit=loaded.thaco-clhit;
   	if(plhit<=ac)
   	{
      	srand((unsigned)time(NULL));
      	tpmon=rand()%10+1;
      	if(tpmon<=5 && ghp1>0)
      	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		ghp1-=dam;
         	printf("\nYou hit the darkest one of them for %i Hit Points.\n",dam);
         	getch();
			}
			if(tpmon>=6)
      	{
         	if(st2<3)
         	{
         	srand((unsigned)time(NULL));
      		dam=rand()%8+1;
      		ghp2-=dam;
         	printf("\nYou hit the one brightest in color for %i Hit Points.\n",dam);
         	getch();
				}
            else printf("\nYou totally missed dude!\n");
			}
         else printf("\nThat was a total miss dude!\n");
		}
   	else
      {
         srand((unsigned)time(NULL));
         ranatt=rand()%9+1;
			if(ranatt==1)printf("\nYou didn't hit.\n");
         if(ranatt==2)printf("\nThe golem blocks your attack with his small shield.\n");
         if(ranatt==3)printf("\nThe golem dodges your attack.\n");
         if(ranatt==4)printf("\nYou miss the golem with a inch.\n");
         if(ranatt==5)printf("\nThe golem leaps to the leaft, away from your attack.\n");
         if(ranatt==6)printf("\nYou miss and your sword allmost falls out of your hands.\n");
         if(ranatt==7)printf("\nYou simply miss.\n");
         if(ranatt==8)printf("\nThe golem blocks your attack with his shield in a groovie golem way.\n");
         if(ranatt==9)printf("\nThe golem blocks your attack with his shield in a groovie Ninja way.\n");
      }
   	if(ghp2<=0 && endb==0)
   	{
         if(st2<3)
         endb++;
      	printf("\n!!!|_The one with the brightest color is dead_|!!!\n");
      	getch();
   	}
   	if(ghp1<=0 && end==0)
   	{
      	end++;
      	printf("\n!!!|_The darkest one of them is dead_|!!!\n");
      	getch();
   	}
      if(ghp1>0 && ghp2>0)
      {
         srand((unsigned)time(NULL));
      	ranatt3=rand()%4+1;
			if(ranatt3==1)printf("\nThe darkest one swings his steel sword at you.\n");
         if(ranatt3==2)printf("\nThe most one with the brigtest color swings steel sword at you.\n");
         if(ranatt3==3)printf("\nThe darkest one tries to run you through with his bare hands.\n");
         if(ranatt3==4)printf("\nThe brightest one in color tries to run you through with his steel sword.\n");
      }
      if(ghp1>0 && ghp2<=0) printf("\nThe darkest one swings his steel sword at you.\n");
      if(ghp1<=0 && ghp2>0)
      {
         srand((unsigned)time(NULL));
      	ranatt4=rand()%4+1;
      	if(ranatt4==1)printf("\nThe brightest one in color attacks you in a freaked rage.\n");
         if(ranatt4==2)printf("\nThe brightest one in color tries to run you through with his steel sword.\n");
         if(ranatt4==3)printf("\nThe brightest one in color swings his steel sword at you.\n");
         if(ranatt4==4)printf("\nThe brightest one in color tries to brake your ribs.\n");
         getch();
      }
		getch();
   	srand((unsigned)time(NULL));
		clhit=rand()%20+1;
   	monhit=th-clhit;
   	if(monhit<=loaded.armor && zhp_1>0)
   	{
			srand((unsigned)time(NULL));
   		dam=rand()%8+1;
      	loaded.life-=dam;
			printf("\nYou were hit for %i Hit Points.\n",dam);
      	getch();
   	}
      else
      {
         if(ghp1>0 && ghp2>0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(ghp1>0 && ghp2<=0)
         {
      		printf("\nHe didn't hit.\n");
         }
         if(ghp1<=0 && ghp2<=0)
         {
      		printf("\nPhef, the golems are dead.\n");
         }
         if(ghp1<=0 && ghp2>0)
         {
      		printf("\nHe didn't hit.\n");
         }
			else getch();
         getch();
      }

      if(ghp2<=0)st2+=2;
   	if(end==1 && endb==1) end++;
   	if(end>=2)
      {
         xc+=4;
         gdeath=1;
         xpcheck++;
      	free_to_exit();
      }
   	if(loaded.life<=0) pldeath();
	}
}
void free_to_exit(void)
{
   int x;
   int lifer;

   if(gdeath==1)loaded.xp+=840;
   if(loaded.xp>=loaded.nextlev && xpcheck==1)
   {
      srand((unsigned)time(NULL));
      lifer=rand()%10+1;
   	loaded.medlife+=lifer;
      loaded.life+=lifer;
      loaded.nextlev*=2;
      xpcheck++;
   }
	puts("\nThe door that leads back to the rooms you were in collapses together with");
   puts("the rest of the rooms(except the one you are in). You see no reason to why this");
   puts("happened.");
   puts("The door that the golems guarded is the door that exits this place.");
   puts("You can now:");
   puts("(1)Exit the room.");
   puts("(2)Stay here.");
   puts("(3)Get Player Status");
   choice=atoi(gets(chooce));
   if(choice==1)exiit();
   if(choice==2)stayer();
   if(choice==3)getplstat();
   if(choice==4)exit(1);
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   getch();
}
void exiit(void)
{
	puts("\nYou are standing outside in a forest. You start walking around");
   puts("and after a while you start to recocnize where you are. Then you");
   puts("find your way back to town.");
   getch();
   town();
}
void stayer(void)
{
   printf("\n\nYou are in a room that is 3 meters to the north, 3 meters to the south\n");
   printf("(from the west wall door) and 5 meters to the east.\n");
   printf("At the middle of the collapsed east wall door is there a large metal door.\n");
   printf("It is 3 meters wide and 5 meters tall. On each side of the door\n");
	puts("are there 2 dead golems at the west wall door, and");
   puts("a collapsed door at the east wall.");
   puts("You can:");
   puts("(1)Exit");
   puts("(2)Stay");
   puts("(3)Get player stats");
   choice=atoi(gets(chooce));
   if(choice==1)exiit();
   if(choice==2)stayer();
   if(choice==3)getplstat();
   if(choice==4)exit(1);
   if(choice<1)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   if(choice>4)
   {
   	printf("\nChoices must range from 1 to 3.\n");
      getch();
   }
   getch();
}

