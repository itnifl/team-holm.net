#include <stdio.h>
#include <conio.h>
#include <ctype.h>

#define CR 0x0d
#define BC 0x08
#define LF 0x0a
#define ESC 0x1b

void outside(void);
void twnsquare(void);
void town(void);

extern struct player{
   		char name[16];
			int gp;
			int life;
			int medlife;
			int xp;
			int findchance;
			int nextlev;
			int thaco;
			int armor;
   		int dmg;
   		char weapons_carry[16];
   		char protection[16];
			}loaded;

char temp;

void town()
{
	puts("You are in town by the north gate.");
   puts("You can:");
   puts("(A)View map over town.");
   puts("(B)Walk down the main street to the town square.");
   puts("(C)Walk up north out of the north gate.");
   temp=getch();
   temp=toupper(temp);
   switch(temp)
   {
		case('A'):
         puts("           North Gate          ");
      	puts(" _____________|  |_____________");
         puts("|_|        |  |M |  |        |_|");
         puts("|  ________|  |A |  |_____     |");
         puts("| |           |I |        |    |");
         puts("| |Joes Store |N |The Inn |    |");
         puts("| |___________|  |________|    |");
         puts("|                              |");
         puts("|          Town Square         |");
         puts("|  _________         _____     |");
         puts("| |         |       |     |    |");
         puts("| |_____    |_    __|     |    |");
         puts("|       | A   |  |     A  |    |");
         puts("|       |____ |  |________|    |");
         puts("|_                            _|");
         puts("|_|__________________________|_|");
         puts("    A = Appartments             ");
         puts("    There are some houses around the walls too.");
         getch();
         break;
      case('B'):
         twnsquare();
         break;
      case('C'):
      	outside();
         break;
   }
}
void twnsquare(void)
{
	puts("You are standing in the middle of town square.");
   puts("People are chatting and shopping. You are in the middle of town.");
   puts("You can:");
   puts("(A)Enter Joes Store.");
   puts("(B)Enter The Inn.");
   puts("(C)Enter appartments at West side.");
   puts("(D)Enter appartments at East side.");
   puts("(E)Walk up the Main Street to the North Gate.");
   puts("(F)Walk down the main Street.");
   puts("(G)Walk to the east.");
   puts("(H)Walk to the west.");
   puts("(I)View map over town.");
   getch();
}
void outside(void)
{

}
