#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#define CR 0x0d
#define BC 0x08
#define LF 0x0a
#define ESC 0x1b

struct player{
   char name[16];
	int gp;
	int life;
	int medlife;
	int xp;
	int findchance;
	int nextlev;
	int thaco;
	int armor;
   int dmg;
   char weapons_carry[16];
   char protection[16];
	}loaded;

void makecharacter(void);
void loadcharacter(void);
void lookatcharacters(void);
void starter(void);
void adv1_a(void);
void town(void);

void main()
{
   char input;

   while(1)
   {
   	clrscr();
		puts("\n\nWelcome to the World of the Barbarians!\n");
   	puts("Chooce:");
   	puts("M - Make a new character");
   	puts("L - Load a old character");
      puts("C - Look at characters");
      puts("S - Start Playing");
      puts("Q - Quit");
   	input=getch();
   	input=toupper(input);
		switch(input)
   	{
         case('Q'):
         	puts("Bye!");
            exit(0);
         case('S'):
      		starter();
         	break;
   		case('M'):
      		makecharacter();
         	break;
      	case('L'):
         	loadcharacter();
         	break;
         case('C'):
         		lookatcharacters();
               break;
      	default:
				puts("?");
            getch();
            break;
   	}
   }
}
void makecharacter(void)
{
	FILE *character;
   struct player def_player;
   int x,xb,xc;

	puts("Enter name of character:");
   for(x=0;x<16;x++)def_player.name[x]='?';  //So Enter will not recur and brake off the input
   x=0;
   do
   {
   	def_player.name[x]=getch();			//get input
   	switch(def_player.name[x])
      {
         case ESC:
               return;
      	case CR:
               putchar(CR);
               putchar(LF);
      			def_player.name[x]=NULL;
               break;
         case BC:
         		if(x==0)break;
         		putchar(BC);
         		putchar(' ');
         		putchar(BC);
         		x--;
               break;
         default:
               putchar(def_player.name[x]);
               x++;
               break;
      }
      if(x==16)def_player.name[x]=NULL;
   }
   while(def_player.name[x]!=NULL);

	def_player.gp=0;
	def_player.life=20;
	def_player.medlife=20;
	def_player.xp=0;
	def_player.findchance=2;
	def_player.nextlev=950;
	def_player.thaco=19;
	def_player.armor=5;
   def_player.dmg=8;
   strcpy(def_player.weapons_carry,"Long_Sword");
	strcpy(def_player.protection,"Chain_Mail");

   character=fopen("player.dat","a");
   if(character==NULL)
   {
   	printf("Disk Error!");
      fclose(character);
      getch();
      return;
   }
   xb=fwrite(&def_player,sizeof(def_player),1,character);
   if(xb==NULL)
   {
   	printf("Write Error!");
      fclose(character);
      getch();
      return;
   }
   fclose(character);
   puts("\n\nDefault character player saved!");
   getch();
}
void loadcharacter(void)
{
	FILE *character;
   char charactername[16];
   int x,xb,xc;

	puts("Enter name of character to load:");
   x=0;
   do
   {
   	charactername[x]=getch();
   	switch(charactername[x])
      {
         case ESC:
               return;
      	case CR:
               putchar(CR);
               putchar(LF);
      			charactername[x]=NULL;
               break;
         case BC:
         		if(x==0)break;
         		putchar(BC);
         		putchar(' ');
         		putchar(BC);
         		x--;
               break;
         default:
               putchar(charactername[x]);
               x++;
               break;
      }
      if(x==16)charactername[x]=NULL;
   }
   while(charactername[x]!=NULL);

   character=fopen("player.dat","r");
   if(character==NULL)
   {
   	printf("No player characters exist!");
      fclose(character);
      getch();
      return;
   }
   while(1)
   {
   	xb=fread(&loaded,sizeof(loaded),1,character);
   	if(xb==NULL)
   	{
   		printf("\nRead error, or character does not exist!");
      	getch();
         fclose(character);
      	return;
   	}
   	if(strcmpi(loaded.name,charactername)==NULL)break;
   }
   fclose(character);
   puts("\n\nPlayer Character Loaded!");
   getch();
}
void lookatcharacters(void)
{
	FILE *look;
   int x,xc;
   struct player looker;

   look=fopen("player.dat","r");
   while(1)
   {
      x=fread(&looker,sizeof(looker),1,look);
      if(x==NULL)
      {
         fclose(look);
         break;
      }
      printf("Character Name: %s\n",looker.name);
      printf("Character Life: %i\n",looker.life);
      printf("Character XP: %i\n",looker.xp);
      printf("Character Thaco: %i\n",looker.thaco);
      printf("Character Armor: %i\n",looker.armor);
      printf("Carrying:\n");
      printf("%s\t",looker.weapons_carry);
      printf("\nAnd Wearing: %s\n",looker.protection);
      getch();
      putchar('\n');
   }
   clrscr();
   printf("Loaded Character:\n");
   getch();
   printf("Character Name: %s\n",loaded.name);
   printf("Character Life: %i\n",loaded.life);
   printf("Character XP: %i\n",loaded.xp);
   printf("Character Thaco: %i\n",loaded.thaco);
   printf("Character Armor: %i\n",loaded.armor);
	printf("Carrying:\n");
   printf("%s\t",loaded.weapons_carry);
   printf("\nAnd Wearing: %s\n",loaded.protection);
   getch();

}
void starter(void)
{
	if(isalpha(loaded.name[0])==NULL && isalpha(loaded.name[1])==NULL)
   {
   	puts("You have to load a character first!");
      getch();
      return;
   }
   clrscr();
   if(loaded.thaco==19)adv1_a();
   if(loaded.thaco<19)
   {
   	town();
   }

}
