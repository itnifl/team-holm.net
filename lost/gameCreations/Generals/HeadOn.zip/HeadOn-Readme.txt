Created 11.08.03 and 12.08.03

This map has after playing it with a friend shown to develop long lasting 
standoffs in the bridge area. Long ranging artillery and rockets 
play a central role in the gameplay. Good usage of airsupport and the use of
airunits allso play a central role. Tanks and such get useful 
in the final attack, but easily gets driven back and a counterattack begins.
After playing like this for about 3 hours, with attacks and counter attacks, 
I gave up after enouhg testing(my PC lags terribly with its old
grapics card, so some of the playtime is due to slow gaming).

The map was tested playing USA and China.

- Atle Holm