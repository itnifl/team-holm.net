#! /bin/bash

if [ $# != 1 ]; then echo "Usage: ./install.sh /pathto/movieLister.tar.gz"; exit 1; fi
cd /
tar xzvf $1
mkdir -p /var/www/fonts 1> /dev/null 2> /dev/null
mkdir -p /var/www/images 1> /dev/null 2> /dev/null
mkdir -p /var/www/coverCache 1> /dev/null 2> /dev/null
mkdir -p /etc/movieLister 1> /dev/null 2> /dev/null
mkdir -p /usr/lib/cgi-bin 1> /dev/null 2> /dev/null

chown -R www-data /var/www/fonts 1> /dev/null 2> /dev/null
chown -R www-data /var/www/images 1> /dev/null 2> /dev/null
chown -R www-data /var/www/coverCache 1> /dev/null 2> /dev/null
chown -R www-data /etc/movieLister 1> /dev/null 2> /dev/null

chmod -R 755 /var/www/coverCache
chmod 755 /var/www/movieStyle.css
chmod 755 /var/www/fonts/bladrmf_.eot
chmod 755 /var/www/fonts/bladrmf_.ttf
chmod 755 /var/www/fonts/daysLater.eot
chmod 755 /var/www/fonts/daysLater.ttf
chmod 755 /var/www/fonts/daysLater.svg
chmod 755 /var/www/fonts/daysLater.woff
chmod 755 /var/www/fonts/bladrmf_.svg
chmod 755 /var/www/fonts/bladrmf_.woff
chmod 755 /var/www/images/warning.png
chmod 755 /var/www/images/playButton.png
chmod 755 /etc/movieLister/movieLister.conf
chmod 755 /usr/lib/cgi-bin/movieLister.pl

chown www-data /var/www/movieStyle.css
chown www-data /var/www/fonts/bladrmf_.eot
chown www-data /var/www/fonts/bladrmf_.ttf
chown www-data /var/www/fonts/daysLater.eot
chown www-data /var/www/fonts/daysLater.ttf
chown www-data /var/www/fonts/daysLater.svg
chown www-data /var/www/fonts/daysLater.woff
chown www-data /var/www/fonts/bladrmf_.svg
chown www-data /var/www/fonts/bladrmf_.woff
chown www-data /var/www/images/warning.png
chown www-data /var/www/images/playButton.png
chown www-data /etc/movieLister/movieLister.conf
chown www-data /usr/lib/cgi-bin/movieLister.pl