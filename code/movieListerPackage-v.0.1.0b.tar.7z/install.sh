#! /bin/bash

if [ $# != 1 ]; then echo "Usage: ./install.sh /pathto/movieLister.tar.gz"; exit 1; fi
cd /
mkdir -p /usr/share/movieLister/fonts 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/images 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/js 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/coverCache 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/css 1> /dev/null 2> /dev/null
mkdir -p /etc/movieLister 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/cgi-bin 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/setup 1> /dev/null 2> /dev/null
mkdir -p /usr/share/movieLister/symlinks 1> /dev/null 2> /dev/null

tar xzvf $1

chown -R www-data /usr/share/movieLister 1> /dev/null 2> /dev/null
chown -R www-data /etc/movieLister 1> /dev/null 2> /dev/null
chown -R www-data /etc/apache2/conf.d/movieLister.conf 1> /dev/null 2> /dev/null

chmod -R 755 /usr/share/movieLister
chmod -R 755 /etc/movieLister
chmod -R 755 /etc/apache2/conf.d/movieLister.conf