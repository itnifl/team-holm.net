#! /bin/bash

if [ $# != 1 ]; then echo "Usage: ./install.sh /pathto/movieLister.tar.gz"; exit 1; fi
cd /
mkdir -p /var/www/fonts 1> /dev/null 2> /dev/null
mkdir -p /var/www/images 1> /dev/null 2> /dev/null
mkdir -p /var/www/js 1> /dev/null 2> /dev/null
mkdir -p /var/www/coverCache 1> /dev/null 2> /dev/null
mkdir -p /var/www/css 1> /dev/null 2> /dev/null
mkdir -p /etc/movieLister 1> /dev/null 2> /dev/null
mkdir -p /usr/lib/cgi-bin 1> /dev/null 2> /dev/null

tar xzvf $1

chown -R www-data /var/www/fonts 1> /dev/null 2> /dev/null
chown -R www-data /var/www/images 1> /dev/null 2> /dev/null
chown -R www-data /var/www/js 1> /dev/null 2> /dev/null
chown -R www-data /var/www/coverCache 1> /dev/null 2> /dev/null
chown -R www-data /var/www/css 1> /dev/null 2> /dev/null
chown -R www-data /etc/movieLister 1> /dev/null 2> /dev/null

chmod -R 755 /var/www/coverCache
chmod 755 /var/www/fonts/bladrmf_.eot
chmod 755 /var/www/fonts/bladrmf_.svg
chmod 755 /var/www/fonts/bladrmf_.ttf
chmod 755 /var/www/fonts/bladrmf_.woff
chmod 755 /var/www/fonts/daysLater.eot
chmod 755 /var/www/fonts/daysLater.svg
chmod 755 /var/www/fonts/daysLater.ttf
chmod 755 /var/www/fonts/daysLater.woff
chmod 755 /var/www/images/bullet.gif
chmod 755 /var/www/images/close.gif
chmod 755 /var/www/images/closelabel.gif
chmod 755 /var/www/images/download-icon.gif
chmod 755 /var/www/images/getFilePath.png
chmod 755 /var/www/images/getFilePathHover.png
chmod 755 /var/www/images/getFilePathHover-small.png
chmod 755 /var/www/images/getFilePath-small.png
chmod 755 /var/www/images/loading.gif
chmod 755 /var/www/images/nextlabel.gif
chmod 755 /var/www/images/penguin.jpg
chmod 755 /var/www/images/playButton.png
chmod 755 /var/www/images/prevlabel.gif
chmod 755 /var/www/images/warning.png
chmod 755 /var/www/js/builder.js
chmod 755 /var/www/js/effects.js
chmod 755 /var/www/js/lightbox.js
chmod 755 /var/www/js/lightbox-web.js
chmod 755 /var/www/js/movieLister.js
chmod 755 /var/www/js/prototype.js
chmod 755 /var/www/js/scriptaculous.js
chmod 755 /var/www/css/lightbox.css
chmod 755 /var/www/css/movieStyle.css
chmod 755 /usr/lib/cgi-bin/movieListPopulator.pl
chmod 755 /usr/lib/cgi-bin/movieLister.pl
chmod 755 /usr/lib/cgi-bin/mlister-smallTable.pl
chmod 755 /usr/lib/cgi-bin/mlister-mediumTable.pl
chmod 755 /usr/lib/cgi-bin/mlister-bigTable.pl
chmod 755 /etc/movieLister/movieLister.conf

chown -R www-data /var/www/coverCache
chown www-data /var/www/fonts/bladrmf_.eot
chown www-data /var/www/fonts/bladrmf_.svg
chown www-data /var/www/fonts/bladrmf_.ttf
chown www-data /var/www/fonts/bladrmf_.woff
chown www-data /var/www/fonts/daysLater.eot
chown www-data /var/www/fonts/daysLater.svg
chown www-data /var/www/fonts/daysLater.ttf
chown www-data /var/www/fonts/daysLater.woff
chown www-data /var/www/images/bullet.gif
chown www-data /var/www/images/close.gif
chown www-data /var/www/images/closelabel.gif
chown www-data /var/www/images/download-icon.gif
chown www-data /var/www/images/getFilePath.png
chown www-data /var/www/images/getFilePathHover.png
chown www-data /var/www/images/getFilePathHover-small.png
chown www-data /var/www/images/getFilePath-small.png
chown www-data /var/www/images/loading.gif
chown www-data /var/www/images/nextlabel.gif
chown www-data /var/www/images/penguin.jpg
chown www-data /var/www/images/playButton.png
chown www-data /var/www/images/prevlabel.gif
chown www-data /var/www/images/warning.png
chown www-data /var/www/js/builder.js
chown www-data /var/www/js/effects.js
chown www-data /var/www/js/lightbox.js
chown www-data /var/www/js/lightbox-web.js
chown www-data /var/www/js/movieLister.js
chown www-data /var/www/js/prototype.js
chown www-data /var/www/js/scriptaculous.js
chown www-data /var/www/css/lightbox.css
chown www-data /var/www/css/movieStyle.css
chown www-data /usr/lib/cgi-bin/movieListPopulator.pl
chown www-data /usr/lib/cgi-bin/movieLister.pl
chown www-data /usr/lib/cgi-bin/mlister-smallTable.pl
chown www-data /usr/lib/cgi-bin/mlister-mediumTable.pl
chown www-data /usr/lib/cgi-bin/mlister-bigTable.pl
chown www-data /etc/movieLister/movieLister.conf