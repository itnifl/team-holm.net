ChatSystem - Flaky version

This is a chat server and a chat client written in Java. I call this
the Flaky version since it works, but with occational bugs. This is no
attempt of creating a professional usable chatsystem, just me having fun with Java.

Usage:
Run the server from the command line like this:
java -jar ChatSystem-Server.jar <port>
where <port> is the port number that the server is going to listen on.
Make sure that no firewall is blocking access to this port. The client
that connects to this port will be listening on one port number higher
then the server.

Run the client from another computer in the network:
java -jar ChatSystem-Client.jar <ip-address> <port>
where <port> is the port number that the server is listening on and
<ip-address> is the ip-address of the server.
Make sure that no firewall is blocking communication on this port and the 
port one number higher.

You can connect as many clients as you want.

Suggested improvements for next release(if any):
*Check that a client doesn't connect with a nick that is already in use
*Make accidental disconnection more smooth and less cryptical
*Let clients send private messages to each other
*Fix bugs


/Atle Holm
atle@team-holm.net