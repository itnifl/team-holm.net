/*
	Sets up a chat client, it implements:
		* A graphical window for the client via the class ChatWindow[OK]
		* A connection to the server and communication with the server via a socket[OK]
*/
import java.net.*;
import java.io.*;

class ChatClient {
    private int port;
    private String address;
    private String clientName = null;
    Socket clientConnection = null;
    ChatWindow clientWindow = null;
    ClientInfo clientInfo = null;
    PrintWriter serverPrinter = null;
	
    public ChatClient(String address, int port, String clientName) {
	this.clientName = clientName;
	this.address = address;
	this.port = port;
	byte[] ipAddr = null;
	try {
            clientConnection = new Socket(address, port);
	} catch (IOException e) {
            System.out.println("Error connecting to: " + address);
            System.out.println(e.toString());
	}
	try {
            InetAddress addr = InetAddress.getLocalHost();
            ipAddr = addr.getAddress();
	} catch(UnknownHostException e) {
            System.out.println("Error getting local address.");
            System.out.println(e.toString());
	}
	/* After connecting and storing our client information, the first thing we do is send our client name to the server
         * The PrintWriter that is created here is used also by the ClientListeningThread to send text to the server
         */
	clientInfo = new ClientInfo(clientName, ipAddr, port);
	try {
            serverPrinter = new PrintWriter(clientConnection.getOutputStream(), true);
            serverPrinter.println(clientName);
            //serverPrinter.close();
	} catch (IOException e) {
            System.out.println("Error sending clientInfo to server");
            System.out.println(e.toString());
	}		
	clientWindow = new ChatWindow(this);
	clientWindow.setVisible(true);
    }
    public String getName() {
	return clientName;
    }
    public ClientInfo getClientInfo() {
	return clientInfo;
    }
    public Socket getSocketConnection() {
	return clientConnection;
    }
    public PrintWriter getServerPrinter() {
        return serverPrinter;
    }
    public void closeServerPrinter() {
        try {
            serverPrinter.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

class ClientInfo implements Serializable { //We want objects of this class to be serialized for possible communication over the network
    private String clientName;
    private byte[] ipAddr;
    private int port;

    public ClientInfo(String clientName, byte[] ipAddr, int port) {
        this.clientName = clientName;
	this.ipAddr = ipAddr;
	this.port = port;
	//this.socket = socket;
    }
    public String getName() {
	return clientName;
    }
    public byte[] getAddress() {
	return ipAddr;
    }
    public int getPort() {
	return port;
    }
}