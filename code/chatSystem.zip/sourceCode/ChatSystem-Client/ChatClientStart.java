/*
	Starts a chat client represented by an object of ChatClient
*/
import java.lang.*;
import static javax.swing.JOptionPane.*;

class ChatClientStart {
    public static void main(String[] args) {
	String address = null;
	int port = 0;
		
	if (args.length >= 2) {
            try {
                port = Integer.parseInt(args[1]);
                address = args[0];
            } catch (Exception e) {
                System.out.println("When starting the client, only numeric values can be given as an argument for port number.");
                System.out.println("Usage: java -jar ChatSystem-Client.jar <chatServerAddress> <port>");
                System.exit(-1);
            }
	String clientName = showInputDialog("Please enter the name of you'r chat client.");
	ChatClient client = new ChatClient(address, port, clientName);
	} else {
            System.out.println("Usage: java ChatClientStart <chatServerAddress> <port>");
            System.exit(-1);
	}
    }
}