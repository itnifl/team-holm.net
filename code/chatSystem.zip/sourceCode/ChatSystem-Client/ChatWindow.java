/*
 * Sets up a chat window for the client.
 * Listen to messages from the server on one port number higher then the port the server is listening to
*/

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*; //Collections
import java.net.*;
import java.io.*;

class ChatWindow extends JFrame {
    private ChatClient theClient = null;
    private ClientListeningThread clientListeningThread = null;
	
    private DefaultListModel textListContent = new DefaultListModel();
    private JList textField;
	
    private DefaultListModel usersListContent = new DefaultListModel();
    private JList usersField;
	
    public ChatWindow(ChatClient theClient) {
        setLayout(new BorderLayout(5,5));
	this.theClient = theClient;
	try {
            setTitle("Client: " + theClient.getName());
            setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

            add(new JPanel(), BorderLayout.CENTER);
            add(new ClientPanel(), BorderLayout.WEST);
            add(new ChatPanel(), BorderLayout.EAST);
            add(new InputPanel(), BorderLayout.SOUTH);
            pack();
            //setSize(375,575);
            setResizable(false);
            setLocation(300, 300);
	} catch (Exception e) {
            System.out.println("Error in ChatWindow constructor: " + e);
            System.out.println(e.toString());
	}
	clientListeningThread = new ClientListeningThread(this, (theClient.getClientInfo()).getPort() + 1);
	addWindowListener(new WindowListener());
	clientListeningThread.start();
    }
    private class WindowListener extends WindowAdapter {
	public void windowClosing(WindowEvent event) {
            //When the window closes is when the client gets removed from the list of clients, we have to notify the server that we are leaving
            clientListeningThread.printServerText("/quit", theClient.getSocketConnection());
            clientListeningThread.breakConnection();
            theClient.closeServerPrinter();
            dispose();
            System.exit(0);
        }
    }
    private class ClientPanel extends JPanel {
	public ClientPanel() {
            setLayout(new GridLayout(1, 1, 5, 5));
            usersField = new JList(usersListContent);
            usersField.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            usersField.setSelectedIndex(0);
            JScrollPane scrollPane = new JScrollPane(usersField);
            usersField.addMouseListener(new MouseAdapter(){
                public void mouseClicked(MouseEvent e){
                    if (e.getClickCount() == 2){
                        Object[] clientNames = usersField.getSelectedValues();
                        String clientName = (String) clientNames[0];
                        String message = JOptionPane.showInputDialog("Write in the message you want to send to: " + clientName + " - not implemted yet!");
                        //The rest of this function should set up its own window for chat with the specific client
                    }
                }
            } );
            add(scrollPane);
	}
    }
    private class ChatPanel extends JPanel {
        public ChatPanel() {
            setLayout(new GridLayout(1, 1, 5, 5));
            textField = new JList(textListContent);
            textField.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            textField.setSelectedIndex(0);
            JScrollPane scrollPane = new JScrollPane(textField);
            add(scrollPane);
	}
    }
    private class InputPanel extends JPanel {
	public InputPanel() {
            //Set actionlistener
            final JTextField textInput = new JTextField();
            JButton chatButton = new JButton("Send");
            chatButton.setMnemonic(KeyEvent.VK_ENTER);
            add(textInput);
            add(chatButton);
            setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
            chatButton.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent event) {
                    String message = textInput.getText();
                    if(message != null && !message.equals("") && !message.matches("(/s+)")) clientListeningThread.printServerText(message, theClient.getSocketConnection());
                    if(message.equals("/quit")) {
                        //Close window that initiates the rest of the closing of the client
                        clientListeningThread.printServerText("*gone*", theClient.getSocketConnection());
                        clientListeningThread.printServerText("/quit", theClient.getSocketConnection());
                        clientListeningThread.breakConnection();
                        theClient.closeServerPrinter();
                        dispose();
                        System.exit(0);
                    }
                }
            });
	}
    }
    public void updateChatWindow(String message){
        textListContent.addElement(message);
    }
    public void updateClientList(ClientList cl) {
	ArrayList<ClientInfo> clientInfoList = cl.getClients();
	usersListContent.clear();
	for (ClientInfo ci : clientInfoList) {
            usersListContent.addElement(ci.getName());
	}
    }
    public ChatClient getClient() {
        return theClient;
    }
}

/*This is the thread where the client listens for messages from the server
* It should: 
*	* Listen for messages from the server[OK]
*	* Allow updating of client list[OK]
*	* Allow updating of main window[OK]
*/
class ClientListeningThread extends Thread {
    private ServerSocket listeningSocket = null;
    private Socket serverConnectionSocket = null;
    ObjectInputStream ois = null;
    ObjectOutputStream oos = null;
    private ChatWindow parentWindow;
    private boolean listening = true;
    private ClientList currentList;

	
    public ClientListeningThread(ChatWindow parentWindow, int port) {
	super("clientListeningThread");
	try {
            this.listeningSocket = new ServerSocket(port);
	} catch (IOException e) {
            System.out.println("Could not listen on port: " + port);
            System.out.println(e.toString());
            System.exit(-1);
	}
	this.parentWindow = parentWindow;
	System.out.println("Client is listening for server chat on " + listeningSocket.getInetAddress() + ":" + listeningSocket.getLocalPort());
    }
    public void run() {
	String message = null;
	BufferedReader reader = null;
	InputStreamReader readConnection = null;

	//This loop will represent the main window and handle connection requests from the server:
	while(listening) {
            try {
                serverConnectionSocket = listeningSocket.accept();
            } catch(IOException e) {
		System.out.println("Error listening to socket");
		System.out.println(e.toString());
		System.exit(-1);
            }
            System.out.println("Connection initiated and receiving message from server on " + serverConnectionSocket.getInetAddress().getHostAddress() + ":" + serverConnectionSocket.getLocalPort());
            try {
                readConnection = new InputStreamReader(serverConnectionSocket.getInputStream());
                reader = new BufferedReader(readConnection); //The reader of the connection
                message = reader.readLine();
            } catch(IOException e) {
		System.out.println("Error handling read stream to server");
		System.out.println(e.toString());
		System.exit(-1);
            }
            if (message.equals("null")) {
		//If message is null, we are receiving the client list up next.
                //Read client list and update the list in the window:
		System.out.println("Received message to read object from server..");
		System.out.println("Attempting to read client list from server..");
		try {
                    ois = new ObjectInputStream(serverConnectionSocket.getInputStream());
                    oos = new ObjectOutputStream(serverConnectionSocket.getOutputStream());
                    currentList = (ClientList) ois.readObject();
		} catch(Exception e) {
                    System.out.println("Error handling read stream from server");
                    System.out.println(e.toString());
                    e.printStackTrace();
                    System.exit(-1);
		}
                System.out.println("Updating client list..");
                parentWindow.updateClientList(currentList);
            } else {
                System.out.println("Updating chat window..");
                //Update chatwindow:
                parentWindow.updateChatWindow(message);
            }
            try {
                reader.close();
            } catch(IOException e) {
                System.out.println("Error closing reader from server");
                System.out.println(e.toString());
                System.exit(-1);
            }
        }
    }
    protected void finalize() {
	try {
            oos.close();
            ois.close();
            listeningSocket.close();
            serverConnectionSocket.close();
	} catch (IOException e) {
            System.out.println("Could not close sockets");
            System.out.println(e.toString());
            System.exit(-1);
	}
    }
    public void printServerText(String message, Socket theSocket) {
	PrintWriter printer = null;		
	try {
            printer = parentWindow.getClient().getServerPrinter();
            printer.println(message);
	} catch(Exception e) {
            System.out.println("Error handling write stream to server");
            System.out.println(e.toString());
            e.printStackTrace();
	}
    }
    public void breakConnection() {
	listening = false;
    }
}
//The following class has to be the same for both client and server. It is defined seperately for each of them.
class ClientList implements Serializable {
	private ArrayList<ClientInfo> clientList;

	public ClientList() {
		clientList = new ArrayList<ClientInfo>();
	}
	public void addClient(ClientInfo c) {
		clientList.add(c);
	}
	public void removeClient(ClientInfo c) {
            if(clientList.size() == 1) {
                clientList = new ArrayList<ClientInfo>();
            } else {
                try {
                    System.out.println("Removing client " + c.getName() + " with socket " + InetAddress.getByAddress(c.getAddress()).toString() + ":" + c.getPort() + " from chat..");
                } catch (UnknownHostException ex) {
                    System.out.println(ex.toString());
                }
                clientList.remove(c);
            }
	}
        public void removeClient(String c) {
            ClientInfo client = null;
            for (ClientInfo ci : clientList) {
                if(ci.getName().equals(c)) client = ci;
            }
            try {
                System.out.println("Removing client " + client.getName() + " with socket " + InetAddress.getByAddress(client.getAddress()).toString() + ":" + client.getPort() + " from chat..");
            } catch (UnknownHostException ex) {
                System.out.println(ex.toString());
            }
            clientList.remove(client);
	}
	public ArrayList<ClientInfo> getClients() {
		return clientList;
	}
}