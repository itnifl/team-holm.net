import java.net.*;
import java.io.*;
import java.util.*; //Collections

/* 
 *   The following is an object implementation of a server, that listens to connections.
 *   The server then sets up a thread for each client, that in turn deals with the client.
 *   Note that the thread needs to access the server object to access the client list,
 *   wich is necessary for client informnation and communication
*/
class ChatServer {
    private ServerSocket serverSocket = null;
    private boolean listening = true;
    private ClientList clientList;

    public ChatServer(int port) {
	clientList = new ClientList();
	try {
            serverSocket = new ServerSocket(port);
	} catch (IOException e) {
            System.out.println("Could not listen on port: " + port);
            System.out.println(e.toString());
            System.exit(-1);
	}
        System.out.println("Server listening on " + serverSocket.getInetAddress() + ":" + port);
        try {
            //When the ChatServer starts, we start listening for incomming connections on or socket and thereby starting a ClientServerThread for each connection.
            while (listening) new ClientServerThread(serverSocket.accept(), this).start();
            serverSocket.close();
            } catch (IOException e) {
		System.out.println("Could not listen on port: " + port + ", or had trouble closing the server socket");
		System.out.println(e.toString());
		System.exit(-1);
            }
    }
    public void enlistClient(ClientInfo c) {
        try {
            System.out.println("Enlisting client " + c.getName() + " with socket " + InetAddress.getByAddress(c.getAddress()).toString() + ":" + c.getPort());
        } catch (UnknownHostException ex) {
            System.out.println(ex.toString());
        }
	clientList.addClient(c);
    }
    public ClientInfo getClientInfo(String clientName) {
	for (ClientInfo ci : clientList.getClients()) {
            if(ci.getName().equals(clientName)) return ci;
	}
	return null;
    }
    public ClientList getClientList() {
	return clientList;
    }
    public void notifyClients() {
	//Prpose: For each client, create a socket connection send a complete list of ClientInfo objects.
	//This will enable each client access to information about all other clients, and have a complete list of clients at hand.
	//The objects need to be serialized over the network.
	Socket clientSocket = null;
	ObjectOutputStream oos = null;
	ObjectInputStream ois = null;

        if(clientList.getClients().size() > 0) System.out.println("Setting up connection and communicating clientList objects over the socket..");
        System.out.println("\n- - - - - - - - - - \nThe clientList is as of now:");
        if(clientList.getClients().size() > 0) {            
            for (ClientInfo ci : clientList.getClients()) {
                System.out.println(ci.getName());
            }
        } else System.out.println("* Empty");
        System.out.println("- - - - - - - - - - \n");
	for (ClientInfo ci : clientList.getClients()) {
            InetAddress address = null;
            try {
                address = InetAddress.getByAddress(ci.getAddress());
                System.out.println("   -Trying " + address.toString() + ":" + (ci.getPort() + 1));
		clientSocket = new Socket(address, (ci.getPort() + 1));
            } catch (Exception e) {
		System.out.println("   -ERROR: Failed to connect to client: " + ci.getName());
                System.out.println("   -" + e.toString() + "\n   This means that the client " +  ci.getName() + " is not getting an updated client list!\n");
                continue;
            }
            PrintWriter printer = null;
            try {
                printer = new PrintWriter(clientSocket.getOutputStream(), true); //The printer\sender on this side of the connection
            } catch (IOException e) {
		System.out.println("   -ERROR: Could not open for sending to client when attempting to notify for sending client list");
		System.out.println("   -ERROR: " + e.toString());
		continue;
            }
            System.out.println("\nSending message to client \"" + ci.getName() + "\" that we are sending objects over the socket..");
            String message = null;
            printer.println(message);
            System.out.println("   -Sending clientList to " + ci.getName() + ", server initiating connection to: " + address + ":" + (ci.getPort() + 1));
            try {
		oos = new ObjectOutputStream(clientSocket.getOutputStream());
		ois = new ObjectInputStream(clientSocket.getInputStream());
		oos.reset();
            } catch (Exception e1) {
                System.out.println("   -ERROR when setting up oos and ois: " + e1.toString());
		try {
                    clientSocket.close();
		} catch (Exception e2) {
                    System.out.println("   -ERROR when closing socket: " + e2.toString());
		}
		return;
            }
            System.out.println("\nConnection initiated for object writing to client on: " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());
            try {
		oos.writeObject(clientList);
            } catch (Exception e) {
		System.out.println("   -ERROR: " + e.toString());
                e.printStackTrace();
            }
            try {
		printer.close();
            } catch (Exception e) {
		System.out.println("   -ERROR: Could not close the client printer");
		System.out.println("   -ERROR: " + e.toString());
		continue;
            }
            try {
		oos.flush();
                oos.close();
		ois.close();
		clientSocket.close();
            } catch (Exception e) {
		System.out.println("   -ERROR: " + e.toString());
                continue;
            }
            System.out.println("clientList was successfully sent to client \"" + ci.getName() + "\"");
	}
    }
    public void broadcastToClients(String message, String sender) {
	//Purpose: Broadcast all public messages to all clients
	Socket clientSocket = null;
        message = sender + ": " + message;
	for (ClientInfo ci : clientList.getClients()) {
            InetAddress address = null;
            try {
                address = InetAddress.getByAddress(ci.getAddress());
		clientSocket = new Socket(address, (ci.getPort() + 1));
            } catch (Exception e) {
		System.out.println(e.toString());
            }
            PrintWriter printer = null;
            try {
                printer = new PrintWriter(clientSocket.getOutputStream(), true); //The printer\sender on this side of the connection
            } catch (IOException e) {
		System.out.println("ERROR(broadcastToClients): Could not open for sending to client \"" + ci.getName() + "\"");
		System.out.println(e.toString());
		continue;
            }
            printer.println(message);
            try {
		printer.close();
            } catch (Exception e) {
		System.out.println("Could not close the client printer");
		System.out.println(e.toString());
		System.exit(-1);
            }
            try {
		clientSocket.close();
            } catch (Exception e) {
		System.out.println(e.toString());
            }
	}
    }
}

//The following class has to be the same for both client and server. It is defined seperately for each of them.
class ClientList implements Serializable {
	private ArrayList<ClientInfo> clientList;
	
	public ClientList() {
		clientList = new ArrayList<ClientInfo>();
	}
	public void addClient(ClientInfo c) {
		clientList.add(c);
	}
	public void removeClient(ClientInfo c) {
            if(clientList.size() == 1) {
                clientList = new ArrayList<ClientInfo>();
            } else {
                try {
                    System.out.println("Removing client " + c.getName() + " with socket " + InetAddress.getByAddress(c.getAddress()).toString() + ":" + c.getPort() + " from chat..");
                } catch (UnknownHostException ex) {
                    System.out.println(ex.toString());
                }
                clientList.remove(c);
            }
	}
        public void removeClient(String c) {
            ClientInfo client = null;
            for (ClientInfo ci : clientList) {
                if(ci.getName().equals(c)) client = ci;
            }
            try {
                System.out.println("Removing client " + client.getName() + " with socket " + InetAddress.getByAddress(client.getAddress()).toString() + ":" + client.getPort() + " from chat..");
            } catch (UnknownHostException ex) {
                System.out.println(ex.toString());
            }
            clientList.remove(client);
	}
	public ArrayList<ClientInfo> getClients() {
		return clientList;
	}
}
//The following class has to be the same for both client and server. It is defined seperately for each of them.
class ClientInfo implements Serializable { //We want objects of this class to be serialized for possible communication over the network
    private String clientName;
    private byte[] ipAddr;
    private int port;

    public ClientInfo(String clientName, byte[] ipAddr, int port) {
        this.clientName = clientName;
        this.ipAddr = ipAddr;
        this.port = port;
    }
    public String getName() {
	return clientName;
    }
    public byte[] getAddress() {
	return ipAddr;
    }
    public int getPort() {
	return port;
    }
}
/*This is the thread where the client is handeled
* It should: 
*	* Set up the connection to the client that the client initiates[OK]
*	* Keep a list of connected clients via the ChatServer object, and update that list when the clients connect or disconnect[OK]
*	* Update that list at the client side when the list at the server side changes[OK]
*	* Let clients chat with each other in the same main window[]
*	* Handle direct messages between clients[]
*/
class ClientServerThread extends Thread {
    private Socket clientSocket = null;
    private String clientName;
    private ChatServer parentServer;
    private boolean connected = true;
    private String message = null;
	
    public ClientServerThread(Socket socket, ChatServer parentServer) {
	super("clientServerThread");
	this.clientSocket = socket;
	this.parentServer = parentServer;
	System.out.println("Client initiated connection on " + clientSocket.getInetAddress() + ":" + clientSocket.getLocalPort());
    }
    public void run() {
	//First we read the client name over the network, then we create a ClientInfo object and add it to our list of connected clients:	
	clientName = readClientText(clientSocket);
	System.out.println("Connected client is: " + clientName);
	this.parentServer.enlistClient(new ClientInfo(clientName, (this.clientSocket.getInetAddress()).getAddress(), clientSocket.getLocalPort()));
	//Next we inform and update all clients with the change in clientlist
	this.parentServer.notifyClients();
		
	//This loop will represent the main window and handle connection requests to other clients:
	System.out.println("\nWaiting for messages from " + clientName + "..");
	while(connected) {
            message = readClientText(clientSocket);
            if(message != null) {
                if (message.equals("/quit")) {
                    //The client is disconnecting, remove him from the client list and exit the thread(thereby taking down the connection):
                    (this.parentServer.getClientList()).removeClient(this.parentServer.getClientInfo(clientName));
                    this.parentServer.notifyClients();
                    this.breakConnection();
                } else {
                    //If the client is not leaving by the string '/quit', then we received a message that we will broadcast to all clients
                    this.parentServer.broadcastToClients(message, clientName);
                }
            }
        }
    }
    protected void finalize() {
    //At the end we close the socket connection:
        try {
            breakConnection();
            clientSocket.close();
        } catch (IOException e) {
            System.out.println("Could not close client socket");
            e.printStackTrace();
            System.exit(-1);
        }
	System.out.println("Connection terminated on " + clientSocket.getInetAddress() + ":" + clientSocket.getLocalPort() + ", client: " + clientName);
    }
    public String readClientText(Socket theSocket) {
        String message = null;
	InputStreamReader readConnection = null;
	BufferedReader reader = null;
		
	try {
            readConnection = new InputStreamReader(theSocket.getInputStream());
            reader = new BufferedReader(readConnection); //The reader of the connection
	} catch (IOException e) {
            System.out.println("Could not open for reading from client: " + theSocket.getInetAddress());
            System.out.println(e.toString());
            System.exit(-1);
	}
	try {
            message = reader.readLine();
            //reader.close();
            //readConnection.close();
	} catch (Exception e) {
            System.out.println("Could not close the client printer: " + theSocket.getInetAddress());
            System.out.println(e.toString());
            System.exit(-1);
	}
	return message;
    }
    public void printClientText(String message, Socket theSocket) {
	PrintWriter printer = null;
	try {
            printer = new PrintWriter(theSocket.getOutputStream(), true); //The printer\sender on this side of the connection
	} catch (IOException e) {
            System.out.println("Could not open for sending message to client");
            System.out.println(e.toString());
            return;
	}
	printer.println(message);
	try {
            printer.close();
	} catch (Exception e) {
            System.out.println("Could not close the client printer when sending message to client");
            System.out.println(e.toString());
            return;
	} 
    }

    public void breakConnection() {
	connected = false;
    }
}