/*
	Creates an object that represents the chatserver.
	Thus that way the chatserver is started.
*/
import java.lang.*;

class ChatServerStart {
    public static void main(String[] args) {
	int port = 0;
	if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (Exception e) {
		System.out.println("When starting server, only numeric values can be given as an argument for the port number.");
		System.exit(-1);
            }
            ChatServer server = new ChatServer(port);
        } else {
            System.out.println("To start the server, you have to give the port number it should listen to as an argument on the command line.");
            System.exit(-1);
        }
    }
}