﻿**Atle Holm 21.04.2012
This is the very first version of the movie lister in a very simple format. 
The script might need some tweaking to work on your system.

styles.css is to be placed on web root by default.
fonts folder is to be placed on web root by default.

movieLister-Pre_version.pl is placed under cgi-bin on a Linux system by default.
