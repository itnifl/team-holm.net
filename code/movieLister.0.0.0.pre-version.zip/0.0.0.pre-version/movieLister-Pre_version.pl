#!/usr/bin/perl -w
#Creator: Atle Holm - atle@team-holm.net

use CGI::Pretty;
use CGI;
use Socket 'inet_ntoa';
use Sys::Hostname 'hostname';
my $server = inet_ntoa(scalar gethostbyname(hostname() || 'localhost'));

my $cgi=new CGI;
my @contentNFS2 = glob("/var/www/movieFolder/*");
my $content;
my $file;
my @fields;

print $cgi->header(); #print a header
print $cgi->start_html(-title=>'Video Listing',-style=>{'src'=>'/styles.css'});

print "<div align=\"center\">";
print $cgi->center($cgi->h1("Movies"));
print "</div>";
print "<table border=\"0\" align=\"center\" bgcolor=\"#FF8000\" cellspacing=\"2\">";
print "<tr><td>";
print "<table border=\"0\" align=\"center\" bgcolor=\"white\" cellspacing=\"0\">";
my $lightColor = false;
foreach $content (@contentNFS2) {
	my @videoContent = `ls "$content"`;
	my @videoFile;
	#print "content er ", $content, "\n<br>";
	#print "videoContent er: ", @videoContent, "\n<br>";
	my $videoName =  substr $content, 14;

	foreach $file (@videoContent) {
		if (($file =~ m/divx$/i) || ($file =~ m/mpg$/i) ||  ($file =~ m/avi$/i) || ($file =~ m/mpeg$/i) || ($file =~ m/mkv$/i) || ($file =~ m/mp4$/i) || ($file =~ m/iso$/i) || ($file =~ m/rar$/i) || ($file =~ m/jar$/i) || ($file =~ m/img$/i)) {
			push(@videoFile, $file);	
		}
	}
    @fields = split /\//, $content;
    #print "Attempting ", $fields[(scalar @fields) - 1]; #Used for testing
	#print "videoFile er ", @videoFile;
	my $X = 0;
	foreach $vid (@videoFile) { 
		$X ++;
		my $filename = "/var/www/movieFolder/$fields[(scalar @fields) - 1]/$vid";
		chomp($filename);
		my $size = -s $filename;
		if ($lightColor eq false) {
			if ($size < 100994432) {
				print "<tr><td onMouseOver=\"style.backgroundColor='Silver';\" onMouseOut=\"style.backgroundColor='Beige';\" bgcolor=\"Beige\">";
				print $cgi->a({-href=>"http://".$server."/movieFolder/$fields[(scalar @fields) - 1]/$vid", -class=>"movieLinks-LightSkyBlue-small"}, $cgi->ul($cgi->li($videoName, "- Video Sample")));	
				print "</td></tr>";
 				$X --;
			} else {
				print "<tr><td onMouseOver=\"style.backgroundColor='Silver';\" onMouseOut=\"style.backgroundColor='Beige';\" bgcolor=\"Beige\">";
				print $cgi->a({-href=>"http://".$server."/movieFolder/$fields[(scalar @fields) - 1]/$vid", -class=>"movieLinks-LightSkyBlue-small"}, $cgi->ul($cgi->li($videoName, "- Video ", $X)));
				print "</td></tr>";
			}
			$lightColor = true;
		} else {
            if ($size < 100994432) {
                print "<tr><td onMouseOver=\"style.backgroundColor='Silver';\" onMouseOut=\"style.backgroundColor='Azure';\" bgcolor=\"Azure\">";
                print $cgi->a({-href=>"http://".$server."/movieFolder/$fields[(scalar @fields) - 1]/$vid", -class=>"movieLinks-LightSkyBlue-small"}, $cgi->ul($cgi->li($videoName, "- Video Sample")));
                print "</td></tr>";
                $X --;
            } else {
                print "<tr><td onMouseOver=\"style.backgroundColor='Silver';\" onMouseOut=\"style.backgroundColor='Azure';\" bgcolor=\"Azure\">";
                print $cgi->a({-href=>"http://".$server."/movieFolder/$fields[(scalar @fields) - 1]/$vid", -class=>"movieLinks-LightSkyBlue-small"}, $cgi->ul($cgi->li($videoName, "- Video ", $X)));
                print "</td></tr>";
            }
			$lightColor = false;
		}
	}
}
print "</table>";
print "</td></tr>";
print "</table><br />";
print "End of video list with a total of ", scalar @contentNFS2, " video files...";
print $cgi->end_html();